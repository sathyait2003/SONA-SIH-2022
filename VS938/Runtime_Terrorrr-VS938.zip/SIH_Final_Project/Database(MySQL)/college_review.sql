-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 26, 2022 at 05:03 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `college_review`
--

-- --------------------------------------------------------

--
-- Table structure for table `colleges`
--

CREATE TABLE `colleges` (
  `CID` bigint(20) NOT NULL,
  `CollegeName` varchar(200) DEFAULT 'No Name',
  `Address` varchar(500) DEFAULT 'No Address',
  `ContactNumber` varchar(100) DEFAULT 'No Contact',
  `Description` varchar(2000) DEFAULT 'No Description',
  `UID` bigint(20) DEFAULT 0,
  `State` varchar(25) DEFAULT 'No State',
  `Rating` float DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `colleges`
--

INSERT INTO `colleges` (`CID`, `CollegeName`, `Address`, `ContactNumber`, `Description`, `UID`, `State`, `Rating`) VALUES
(1, 'ABESEC', 'Ghaziabad, Uttar Pradesh', '9876598765', 'ABESEC, Ghaziabad', 2, 'Uttar Pradesh', 0),
(2, 'jss', 'na', '8468028345', 'jss is the best college', 3, 'Uttar Pradesh', 0),
(3, 'IIT Delhi', 'Delhi', '1111111111', 'Sexy College', 4, 'Delhi', 0),
(4, 'ABESIT', 'Ghaziabad', '1234567890', 'nice college', 10, 'Uttar Pradesh', 0),
(5, 'AKG', 'NH-24, Ghaziabad', '9873186603', 'Best college in Ghazabad', 13, 'Uttar Pradesh', 0),
(6, 'IIT MUMBAI', 'pawai lake', '98312128319831298319390 vasooli kr le ', 'Dharavi ke peeche.', 15, 'Maharashtra', 0),
(7, 'No Name', 'No Address', 'No Contact', 'No Description', 18, 'No State', 0),
(8, 'No Name', 'No Address', 'No Contact', 'No Description', 20, 'No State', 0),
(9, 'No Name', 'No Address', 'No Contact', 'No Description', 21, 'No State', 0),
(10, 'No Name', 'No Address', 'No Contact', 'No Description', 22, 'No State', 0),
(11, 'IIT Guwahati', 'Guwahati, Assam', '9895793633', 'IIT Guwahati', 23, 'Assam', 3.9),
(12, 'No Name', 'No Address', 'No Contact', 'No Description', 29, 'No State', 0),
(13, 'No Name', 'No Address', 'No Contact', 'No Description', 30, 'No State', 0),
(14, 'No Name', 'No Address', 'No Contact', 'No Description', 31, 'No State', 0),
(16, 'Sona College of Technology', ' Junction Main Road, Salem 636 005. Tamil Nadu, India.', '9442668758', 'Sona College of Technology is a private engineering institution that offers engineering degree programmes at under graduate level and post graduate level, computer applications and management studies at post graduate level and doctoral programmes in the areas of engineering and science and humanities.', 35, 'Tamil Nadu', 4.6);

-- --------------------------------------------------------

--
-- Table structure for table `college_reviews`
--

CREATE TABLE `college_reviews` (
  `CRID` bigint(20) NOT NULL,
  `Rating` float DEFAULT 0,
  `Review` varchar(5000) DEFAULT NULL,
  `ReviewDateTime` datetime DEFAULT NULL,
  `PlacementPercent` tinyint(4) DEFAULT 0,
  `FeeStructure` tinyint(4) DEFAULT 0,
  `EducationalGrants` tinyint(4) DEFAULT 0,
  `AcceptanceRate` tinyint(4) DEFAULT 0,
  `StudentFacultyRatio` tinyint(4) DEFAULT 0,
  `LabsAndLibrary` tinyint(4) DEFAULT 0,
  `ClassSizeIndex` tinyint(4) DEFAULT 0,
  `ReviewType` varchar(10) DEFAULT 'Normal',
  `CID` bigint(20) DEFAULT 1,
  `UID` bigint(20) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `college_reviews`
--

INSERT INTO `college_reviews` (`CRID`, `Rating`, `Review`, `ReviewDateTime`, `PlacementPercent`, `FeeStructure`, `EducationalGrants`, `AcceptanceRate`, `StudentFacultyRatio`, `LabsAndLibrary`, `ClassSizeIndex`, `ReviewType`, `CID`, `UID`) VALUES
(2, 3.9, 'Good college', '2022-08-26 00:26:08', 4, 3, 5, 3, 4, 3, 5, 'Anonymous', 11, 24),
(3, 4.35, 'Best college', '2022-08-26 09:35:06', 4, 4, 5, 5, 4, 4, 5, 'Anonymous', 15, 33),
(4, 4.6, 'Best college', '2022-08-26 18:52:34', 5, 5, 4, 3, 5, 5, 5, 'Anonymous', 16, 36);

-- --------------------------------------------------------

--
-- Table structure for table `faculties`
--

CREATE TABLE `faculties` (
  `FID` bigint(20) NOT NULL,
  `FacultyName` varchar(100) DEFAULT 'No Name',
  `Designation` varchar(100) DEFAULT 'No Designation',
  `CID` bigint(20) DEFAULT 1,
  `Rating` float DEFAULT 0,
  `Course` varchar(20) DEFAULT 'CS'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `faculties`
--

INSERT INTO `faculties` (`FID`, `FacultyName`, `Designation`, `CID`, `Rating`, `Course`) VALUES
(1, 'Ravi Sir', 'HOD', 1, 0, 'CS'),
(2, 'Name', 'dddd', 1, 0, 'ME'),
(3, 'cccccccccccccccc', 'ccc', 1, 0, 'Civil'),
(4, 'Akash', 'HOD CS', 11, 0, 'CS'),
(5, 'Aruj', 'HOD Civil', 11, 4.1, 'Civil'),
(6, 'Prashant Sir', 'HOD CS', 15, 3.8, 'CS'),
(7, 'Anuj Sir', 'Asssistant Prof. EC', 15, 0, 'EC'),
(9, 'Dr. B. Sathiyabhama', 'Professor / HOD CS', 16, 4.6, 'CS'),
(10, 'Dr.A.C.Kaladevi', 'Professor Civil', 16, 0, 'Civil');

-- --------------------------------------------------------

--
-- Table structure for table `faculty_reviews`
--

CREATE TABLE `faculty_reviews` (
  `FRID` bigint(20) NOT NULL,
  `Rating` float DEFAULT 0,
  `Review` varchar(2000) DEFAULT NULL,
  `ReviewDateTime` datetime DEFAULT NULL,
  `Preparedness` tinyint(4) DEFAULT 0,
  `Explaination` tinyint(4) DEFAULT 0,
  `TeachingAids` tinyint(4) DEFAULT 0,
  `Availability` tinyint(4) DEFAULT 0,
  `Discussion` tinyint(4) DEFAULT 0,
  `Examples` tinyint(4) DEFAULT 0,
  `FID` bigint(20) DEFAULT 1,
  `UID` bigint(20) DEFAULT 1,
  `ReviewType` varchar(10) DEFAULT 'Normal'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `faculty_reviews`
--

INSERT INTO `faculty_reviews` (`FRID`, `Rating`, `Review`, `ReviewDateTime`, `Preparedness`, `Explaination`, `TeachingAids`, `Availability`, `Discussion`, `Examples`, `FID`, `UID`, `ReviewType`) VALUES
(2, 4.1, 'Nice faculty', '2022-08-26 00:31:51', 4, 4, 5, 5, 3, 4, 5, 26, 'Normal'),
(3, 3.8, 'Good', '2022-08-26 09:36:52', 3, 4, 4, 3, 5, 4, 6, 33, 'Normal'),
(4, 4.6, 'good', '2022-08-26 18:53:26', 4, 5, 5, 4, 4, 5, 9, 36, 'Normal');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `UID` int(11) NOT NULL,
  `UserName` varchar(30) DEFAULT NULL,
  `Email` varchar(30) DEFAULT NULL,
  `College` text NOT NULL,
  `PWD` varchar(100) DEFAULT NULL,
  `Status` varchar(10) DEFAULT 'Pending',
  `LastCheck` datetime DEFAULT NULL,
  `Mobile` varchar(10) DEFAULT NULL,
  `UserType` varchar(20) DEFAULT 'User',
  `CreatedOn` date DEFAULT NULL,
  `Address` varchar(500) DEFAULT 'No Address',
  `Description` varchar(250) DEFAULT 'Description',
  `KidID` bigint(20) DEFAULT 0,
  `Course` varchar(25) DEFAULT NULL,
  `Designation` varchar(50) DEFAULT 'Student',
  `CID` bigint(20) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`UID`, `UserName`, `Email`, `College`, `PWD`, `Status`, `LastCheck`, `Mobile`, `UserType`, `CreatedOn`, `Address`, `Description`, `KidID`, `Course`, `Designation`, `CID`) VALUES
(1, 'Admin', 'admin@gmail.com', '--', 'aa', 'Approved', NULL, '7007502988', 'Admin', '2021-07-01', 'No Address', 'Description', 0, '', 'Admin', 1),
(3, 'Student', 's@gmail.com', '', 'aa', 'Approved', NULL, '7777777777', 'Student', '2022-08-22', 'No Address', 'Description ', 0, '', 'Designation', 1),
(25, 'Aditya', 'aditya@gmail.com', '', '9227839972', 'Approved', NULL, '9227839972', 'Parent', '2022-08-26', 'No Address', 'Description', 24, 'Computer Science', 'Designation', 11),
(26, 'Anchal', 'anchal@gmail.com', '', '9877828882', 'Approved', NULL, '9877828882', 'Student', '2022-08-26', 'No Address', 'Description', 0, 'Civil', 'Designation', 11),
(27, 'Anchal Parent', 'anchalp@gmail.com', '', '8383838287', 'Approved', NULL, '8383838287', 'Parent', '2022-08-26', 'No Address', 'Description', 26, 'Computer Science', 'Designation', 11),
(28, 'Aryan', 'aryan@gmail.com', '', '9876543210', 'Approved', NULL, '9876543210', 'Student', '2022-08-26', 'No Address', 'Description', 0, 'CS', 'Designation', 11),
(31, 'Rajat', 'rajat@gmail.com', 'KIET', '961b6dd3ede3cb8ecbaacbd68de040cd78eb2ed5889130cceb4c49268ea4d506', 'Approved', NULL, '8378399272', 'Representative', NULL, 'No Address', 'Description', 0, 'Computer Science', '', 14),
(35, 'Dr.S.R.R.SENTHIL KUMAR', 'principal@gmail.com', 'Sona College of Technology', '961b6dd3ede3cb8ecbaacbd68de040cd78eb2ed5889130cceb4c49268ea4d506', 'Approved', NULL, '9442668758', 'Representative', NULL, 'No Address', 'Description', 0, NULL, 'Principal', 16),
(36, 'Akash Bansal', 'akash@gmail.com', 'Sona College of Technology', '9811377986', 'Approved', NULL, '9811377986', 'Student', '2022-08-26', 'No Address', 'Description', 0, 'CS', 'Student', 16),
(37, 'Aruj Singh', 'aruj@gmail.com', 'Sona College of Technology', '9898989898', 'Approved', NULL, '9898989898', 'Student', '2022-08-26', 'No Address', 'Description', 0, 'Civil', 'Designation', 16),
(38, 'Akash Parent 1', 'akashp1@gmail.com', 'Sona College of Technology', '8989898989', 'Approved', NULL, '8989898989', 'Parent', '2022-08-26', 'No Address', 'Description', 36, NULL, 'Designation', 16),
(39, 'Akash Parent 2', 'akashp2@gmail.com', 'Sona College of Technology', '9191919191', 'Approved', NULL, '9191919191', 'Parent', '2022-08-26', 'No Address', 'Description', 36, NULL, 'Designation', 16);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `colleges`
--
ALTER TABLE `colleges`
  ADD PRIMARY KEY (`CID`);

--
-- Indexes for table `college_reviews`
--
ALTER TABLE `college_reviews`
  ADD PRIMARY KEY (`CRID`);

--
-- Indexes for table `faculties`
--
ALTER TABLE `faculties`
  ADD PRIMARY KEY (`FID`);

--
-- Indexes for table `faculty_reviews`
--
ALTER TABLE `faculty_reviews`
  ADD PRIMARY KEY (`FRID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`UID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `colleges`
--
ALTER TABLE `colleges`
  MODIFY `CID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `college_reviews`
--
ALTER TABLE `college_reviews`
  MODIFY `CRID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `faculties`
--
ALTER TABLE `faculties`
  MODIFY `FID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `faculty_reviews`
--
ALTER TABLE `faculty_reviews`
  MODIFY `FRID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `UID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
