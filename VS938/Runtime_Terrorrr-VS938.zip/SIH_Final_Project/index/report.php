<?php
session_start();
if(isset($_SESSION["UID"])){$UID=$_SESSION["UID"];}else{header("Login.php");return;}
include('assets/phpscript/FormatedOutput.php');
include('assets/Database/DBMySql.php');
$db=new DBMySql;

// if(isset($_GET["Accept"])){$db->NonQuery("UPDATE `users` SET `Status` = 'Approved' WHERE UID=".$_GET["Accept"]);}
// if(isset($_GET["Reject"])){$db->NonQuery("UPDATE `users` SET `Status` = 'Rejected' WHERE UID=".$_GET["Reject"]);}




?>
<html>

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no" />
    <title>Review Hub</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css" />
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css" />
    <link rel="stylesheet" href="assets/fonts/fontawesome5-overrides.min.css" />
    <link rel="stylesheet" href="assets/css/Contact-Form-Clean.css" />
    <link rel="stylesheet" href="assets/css/Features-Boxed.css" />
    <link rel="stylesheet" href="assets/css/Features-Clean.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css" />
    <link rel="stylesheet" href="assets/css/Sidebar-Menu-1.css" />
    <link rel="stylesheet" href="assets/css/Sidebar-Menu.css" />
    <link rel="stylesheet" href="assets/css/styles.css" />
    <script src="assets/js/angular.min.js"></script>
    <script src="assets/js/angular-sanitize.min.js"></script>


    <script src="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.12/cropper.min.js" integrity="sha512-ooSWpxJsiXe6t4+PPjCgYmVfr1NS5QXJACcR/FPpsdm6kqG1FmQ2SVyg2RXeVuCRBLr0lWHnWJP6Zs1Efvxzww==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.12/cropper.min.css" integrity="sha512-0SPWAwpC/17yYyZ/4HSllgaK7/gg9OlVozq8K7rf3J8LvCjYEEIfzzpnA2/SSjpGIunCSD18r3UhvDcu/xncWA==" crossorigin="anonymous" referrerpolicy="no-referrer" />


    <style type="text/css">
        img {
            display: block;
            max-width: 100%;
        }
        .preview {
            overflow: hidden;
            width: 160px;
            height: 160px;
            margin: 10px;
            border: 1px solid red;
        }

    </style>
    <script>
        var app = angular.module('myApp', []);
        app.controller('customersCtrl', function ($scope, $http) {
            $scope.Record = { UID:0 };
            $scope.Load = function () {
                $http.get("assets/api/GetFaculties.php").then($http.get("assets/api/GetAVGFacultyReviews.php").then(function (response) {
                    $scope.Records = response.data;
                    $scope.Records.forEach(Record => {

                            Record.ProfileImage = 'assets/img/Faculties/' + Record.FID + '.png?t=' + Date.now();

                        });
                console.log($scope.Records);
            }))
            }
            $scope.Load();
            $scope.Save = function () {
                var Record = $scope.Record;
                $http.get("assets/api/FacultyApi2.php?FID="+Record.FID+"&FacultyName="+Record.FacultyName+"&Designation="+Record.Designation+"&Course="+Record.Course, Record).then ($http.get("assets/api/AddFacultyReviewApi.php?FID="+Record.FID+"&Rating="+Record.FinalRating, Record).then(function (response) {
                console.log(response.data);
                $('#NewRecordModal').modal('hide'); 
            }));
            }

            
            $scope.SetToEdit = function (Record) {
                console.log(Record); 
                $('#NewRecordModal').modal(); 
                $scope.Record = angular.copy(Record);
            }
            // $scope.Delete = function (Record) {
            //     if (!confirm('Confirm Delete?')) return;
            //      $http.get("assets/api/DeleteUsers.php?UID="+Record.UID).then(function (response) {
            //     $scope.Records = response.data;
            //     console.log($scope.Records);
            // });
            // }
           
        });

    </script>







</head>

<body ng-app="myApp" ng-controller="customersCtrl">
    <?php include("menu.php"); ?>
    <div id="wrapper" style="margin-top: 66px;">
        <div class="bg-dark shadow-sm" id="sidebar-wrapper">
            <?php include("sidemenu.php"); ?>
        </div>
        <div class="page-content-wrapper">
            <div class="page-content-wrapper">
               <div class="page-content-wrapper">
    <div class="container-fluid">
        <h1>College Report</h1>
        <hr />
    </div>
    <div class="container-fluid">
        <div class="card">
            <div class="card-header">
                <div>
                    <h6>Top Faculties</h6>
                </div>
            </div>
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th style="width: 50px;">Sn.</th>
                            <th>Name</th>
                            <!-- <th>Email</th> -->
                            <!-- <th>Mobile</th> -->
                            <th>Designation</th>
                            <th>Department</th>
                            <th>Rating</th>

                            <!-- <th class="text-center" style="width: 110px;">Action</th> -->
                        </tr>
                    </thead>
                    <tbody>
                        <tr ng-repeat="Record in Records">
                            <td>{{$index+1}}</td>
                            
                            <td><a href="viewfaculty.php?FID={{Record.FID}}">{{Record.FacultyName}}</a></td>
                            <!-- <td>{{Record.Email}}</td> -->
                            <!-- <td>{{Record.Mobile}}</td> -->
                            <td>{{Record.Designation}}</td>
                            <td>{{Record.Course}}</td>
                            <td>{{Record.FinalRating}}</td>
                            <!-- <td class="text-right">
                                <div class="btn-group" role="group">
                                <a  class="btn btn-info" href="representatives.php?Accept={{Record.UID}}"><i class="fa fa-check"></i></a>
                                <a class="btn btn-danger" href="representatives.php?Reject={{Record.UID}}"><i class="fa fa-remove"></i></a></div>
                            </td> -->
                        </tr>
                       
                    </tbody>
                </table>
            </div>
        </div>
    </div>



    <div class="modal fade" id="modal" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
                            <div class="modal-dialog modal-lg" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="modalLabel">Crop image</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">�</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="img-container">
                                            <div class="row">
                                                <div class="col-md-8">
                                                    <!--  default image where we will set the src via jquery-->
                                                    <img id="image" class="img-fluid" />

                                                </div>
                                                <div class="col-md-4">
                                                    <div class="preview"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                        <button type="button" class="btn btn-primary" id="crop">Crop</button>
                                    </div>
                                </div>
                            </div>
                        </div>


                </div>
            </div>
            <hr />
        </div>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/bs-init.js"></script>
    <script src="assets/js/Sidebar-Menu.js"></script>

    <script src="cropperjs/cropper.min.js" type="text/javascript"></script>
    <script>

    var bs_modal = $('#modal');
    var image = document.getElementById('image');
    var cropper,reader,file;

        var SelectedID = 0;
        $("body").on("change", ".image", function (e) {
            SelectedID=(e.target.title);
        var files = e.target.files;
        var done = function(url) {
            image.src = url;
            bs_modal.modal('show');
        };


        if (files && files.length > 0) {
            file = files[0];

            if (URL) {
                done(URL.createObjectURL(file));
            } else if (FileReader) {
                reader = new FileReader();
                reader.onload = function(e) {
                    done(reader.result);
                };
                reader.readAsDataURL(file);
            }
        }
    });

    bs_modal.on('shown.bs.modal', function() {
        cropper = new Cropper(image, {
            aspectRatio: 1,
            viewMode: 3,
            preview: '.preview'
        });
    }).on('hidden.bs.modal', function() {
        cropper.destroy();
        cropper = null;
    });

        $("#crop").click(function () {
            console.log(SelectedID);
        canvas = cropper.getCroppedCanvas({
            //width: 160,
            //height: 160,
        });
//        var context = canvas.getContext('2d');
//context.beginPath();
//      context.arc(width / 2, height / 2, Math.min(width, height) / 2, 0, 2 * Math.PI, true);
//      context.fill();
        canvas.toBlob(function(blob) {
            url = URL.createObjectURL(blob);
            var reader = new FileReader();
            reader.readAsDataURL(blob);
            reader.onloadend = function() {
                var base64data = reader.result;

                $.ajax({
                    type: "POST",
                    dataType: "json",
                    url: "uploadFacultyImage.php",
                    data: {image: base64data,ID:SelectedID},
                    success: function(data) {
                        bs_modal.modal('hide');
                        location.assign("faculties.php");
                    }
                });
            };
        });
    });

    </script>
</body>

</html>