
<nav class="navbar navbar-dark navbar-expand-md fixed-top bg-dark shadow">
    <div class="container-fluid">
        <a class="btn btn-dark" role="button" id="menu-toggle" href="#menu-toggle">
            <i class="fa fa-bars"></i>
        </a>
        <a class="navbar-brand" href="index.php">Review Hub</a>
        <button data-toggle="collapse" class="navbar-toggler" data-target="#navcol-1">
            <span class="sr-only">Toggle navigation</span>
            <span class="navbar-toggler-icon"></span>
        </button>
        <div
            class="collapse navbar-collapse" id="navcol-1">
            <ul class="nav navbar-nav">
                <li class="nav-item d-xl-flex align-items-xl-center" style="padding: 5px;padding-right: 5px;padding-left: 5px;">
                    <a class="nav-link active" href="search.php">Search College</a>
                </li>
                <li class="nav-item d-xl-flex align-items-xl-center" style="padding: 5px;padding-right: 5px;padding-left: 5px;">
                    <a class="nav-link active" href="about.php">About</a>
                </li>
                <li class="nav-item d-xl-flex align-items-xl-center" style="padding: 5px;padding-right: 5px;padding-left: 5px;">
                    <a class="nav-link active" href="contactus.php">Contact Us</a>
                </li>
                <?php 
                if(isset($_SESSION["UID"]))
                {
                ?>
                <li class="nav-item d-xl-flex align-items-xl-center" style="padding: 5px;padding-right: 5px;padding-left: 5px;">
                    <a class="nav-link active" href="ChangePassword.php">Change Password</a>
                </li>
                <li class="nav-item d-xl-flex align-items-xl-center" style="padding: 5px;padding-right: 5px;padding-left: 5px;">
                    <a class="nav-link active" href="profile.php">Profile</a>
                </li>
                <li class="nav-item d-xl-flex align-items-xl-center" style="padding: 5px;padding-right: 5px;padding-left: 5px;">
                    <a class="nav-link active" href="assets/phpscript/logout.php">Logout</a>
                </li>
                <?php } else { ?>

                    <li class="nav-item d-xl-flex align-items-xl-center" style="padding: 5px;padding-right: 5px;padding-left: 5px;">
                        <a class="nav-link active" href="Login.php">Login</a>
                    </li>
                    <li class="nav-item d-xl-flex align-items-xl-center" style="padding: 5px;padding-right: 5px;padding-left: 5px;">
                        <a class="nav-link active" href="Signup.php">Signup</a>
                    </li>
                <?php } ?>
            </ul>
        </div>
    </div>
</nav>