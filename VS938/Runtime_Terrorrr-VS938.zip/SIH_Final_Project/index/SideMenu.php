<?php
if(session_status()==1){session_start();}



?>

<ul class="sidebar-nav">
    <li class="sidebar-brand">
        <a class="text-white" href="#">Actions</a>
    </li>

    <?php if(isset($_SESSION["UID"])){ ?>
    
    
    <?php if($_SESSION["UserType"]=='Admin'){ ?>
        <li>
            <a class="text-white" href="Representatives.php">Representatives</a>
        </li>
    <li><a class="text-white" href="changepassword.php">Change Password</a>
    </li>
    <li><a class="text-white" href="report_admin.php">UGC Report</a>
    </li>
    <?php }else{?>
    <li>

        <a class="text-white" href="Profile.php">Profile</a>
    
        <a class="text-white" href="viewcollege.php?CID=<?php echo $_SESSION["User"]["CID"]; ?>" >Your College</a>
        
       

    </li>
    <?php }?>
    <?php if($_SESSION['User']["UserType"]=='Representative'){ ?>

            <?php if( $_SESSION['User']["Status"]=='Approved'){ ?>
           

        <li>
            <a class="text-white" href="students.php">Students</a>
        </li>
        <li>
            <a class="text-white" href="Faculties.php">Faculties</a>
        </li>
        <li>
            <a class="text-white" href="collegeprofile.php">College Profile</a>
        </li>
        <?php } ?>
    <li>
        <a class="text-white" href="changepassword.php">Change Password</a>
    </li>
    <li>
        <a class="text-white" href="report2.php">Report</a>
    </li>
    
    <?php } ?>

    
<?php } ?>





    
    
</ul>