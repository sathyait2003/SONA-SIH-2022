<?php
session_start();

$err=$State=$Keyword="";
include('assets/phpscript/FormatedOutput.php');
include('assets/Database/DBMySql.php');
$db=new DBMySql;
$cn=$db->GetActiveConnection();
$ID=0;
if(isset($_GET["CID"])){ $ID=$_GET["CID"];}

if(isset($_GET["AddReview"])){

    $db->NonQueryOnConnection("INSERT INTO `college_reviews`(`Review`,`ReviewDateTime`,`CID`,`UID`) VALUES ('".$_GET["Review"]."',NOW(),".$ID.",".$_SESSION['UID'].")",$cn);
}

if(isset($_GET["DeleteReview"])){

    $db->NonQueryOnConnection("delete from college_reviews where CRID=".$_GET["DeleteReview"],$cn);
    $FinalRating = $db->ScalerQueryOnConnection("SELECT IFNULL(AVG(Rating),0) FROM `college_reviews` WHERE CID=".$ID,$cn);
    $db->NonQueryOnConnection("Update colleges set Rating=".$FinalRating." where CID=".$ID,$cn);

}
$sql="Select * from colleges where CID=".$ID;
$Record = $db->GetSingleRow($sql);

$sql="SELECT `CRID`,`Rating`,`Review`,ReviewType,`ReviewDateTime`,cr.`CID`,u.`UID`,`UserName`,`UserType`,`Course` FROM `college_reviews` cr,users u  WHERE u.`UID`=cr.`UID` AND cr.CID=".$ID;
$Reviews = $db->GetResult($sql);

$sql="SELECT AVG(`Rating`) AS `Rating`,AVG(`PlacementPercent`) AS `PlacementPercent`,AVG(`FeeStructure`) AS `FeeStructure`,AVG(`EducationalGrants`) AS `EducationalGrants`,AVG(`AcceptanceRate`) AS `AcceptanceRate`,AVG(`StudentFacultyRatio`) AS `StudentFacultyRatio`,AVG(`LabsAndLibrary`) AS `LabsAndLibrary`,AVG(`ClassSizeIndex`) AS `ClassSizeIndex` FROM `college_reviews` WHERE CID=".$ID;
$AvgRating=$db->GetSingleRow($sql);

$FacultyCount=$db->ScalerQuery("select COUNT(*) from faculties where CID = ".$ID);

$StateList = SelectOptionsFormArray( ["Delhi","Uttar Pradesh","Bihar"],$State);

$cn->close();


?>


<html>

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no" />
    <title>Review Hub</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css" />
    <link rel="stylesheet" href="assets/css/styles.css" />
<script src="assets/js/myjs.js"></script>
    <script src="assets/js/angular.min.js"></script>
    <script src="assets/js/angular-sanitize.min.js"></script>
    <script>
        function Search() {
            var state = $('#StateList').val();
            location.assign("search.php?State=" + state);
        }
    </script>
    <script>
        var app = angular.module('myApp', []);
        app.controller('customersCtrl', function ($scope, $http) {
            $scope.Record = { UID: 0 };
            $scope.Review = {PlacementPercent:0,FeeStructure:0,EducationalGrants:0,AcceptanceRate:0,StudentFacultyRatio:0,LabsAndLibrary:0,ClassSizeIndex:0,Anonymous:true};
            $scope.SetPlacementPercent = function (val) { $scope.Review.PlacementPercent = val; }
            $scope.SetFeeStructure = function (val) { $scope.Review.FeeStructure = val; }
            $scope.SetEducationalGrants = function (val) { $scope.Review.EducationalGrants = val; }
            $scope.SetAcceptanceRate = function (val) { $scope.Review.AcceptanceRate = val; }
            $scope.SetStudentFacultyRatio = function (val) { $scope.Review.StudentFacultyRatio = val; }
            $scope.SetLabsAndLibrary = function (val) { $scope.Review.LabsAndLibrary = val; }
            $scope.SetClassSizeIndex = function (val) { $scope.Review.ClassSizeIndex = val; }

            var QueryString = QueryStringToJSON();
            //console.log(QueryString);

            $scope.CreateReview = function () {
                $scope.Review.CID = QueryString.CID;
                console.log($scope.Review);
                        var data = JSON.stringify($scope.Review);
                $http.post("assets/api/AddCollegeReviewApi.php", data)
                .then(function (response) {

                    if (response.data.Status == 'Success') {
                        location.assign('viewcollege.php?CID='+$scope.Review.CID);
                    }
                    else {alertify.error(response.data.Message);}
                });





            }

            $scope.ShowPanel = "Details";
            $scope.SetShowPanel = function (Panel) {$scope.ShowPanel = Panel;}
            $scope.Load = function () {
                $http.get("assets/api/GetUsers.php?UserType=Student").then(function (response) {
                    $scope.Records = response.data;
                    $scope.Records.forEach(Record => {

                            Record.ProfileImage = 'assets/img/Users/' + Record.UID + '.png?t=' + Date.now();
                        });
                console.log($scope.Records);
            });
            }
            //$scope.Load();
         
            $scope.SetToEdit = function (Record) {
                console.log(Record);
                $('#NewRecordModal').modal();
                $scope.Record = angular.copy(Record);
            }
            $scope.Delete = function (Record) {
                if (!confirm('Confirm Delete?')) return;
                 $http.get("assets/api/DeleteUsers.php?UID="+Record.UID).then(function (response) {
                $scope.Records = response.data;
                console.log($scope.Records);
            });
            }

        });

    </script>
</head>

<body ng-app="myApp" ng-controller="customersCtrl">
    <?php include('menu.php'); ?>

    <div class="container" style="margin-top: 80px;">
        <h4 class="text-secondary">College Profile</h4>
    </div>
    <hr />
    <div class="container" style="margin-top: 19px;">
        <div class="card mb-4">
            <div class="card-body shadow-sm">
                <div class="row">
                    <div class="col">
                        <img class="border rounded shadow" src="<?php echo "assets/img/Colleges/".$Record["CID"].".png"; ?>" style="max-width: 500px;" />
                    </div>
                    <div class="col">
                        <h4><?php echo $Record["CollegeName"]; ?></h4>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>
                                            <h6 class="text-success mb-2">
                                                <i class="fa fa-star"></i> Rating - <?php echo round( $AvgRating["Rating"],1); ?> / 5 [<?php echo $Reviews->num_rows?$Reviews->num_rows:0; ?> Votes]
                                            </h6>
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>
                                            <span>
                                                Placement percent
                                                <br />
                                            </span>
                                            <?php PrintProgressBarAdvanced ($AvgRating['PlacementPercent'],0,5,'','info');?>
                                           
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <span>
                                                Fee Structure
                                                <br />
                                            </span>
                                            <?php PrintProgressBarAdvanced ($AvgRating['FeeStructure'],0,5,'','info');?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <span>Educational grants on Academic performance</span>
                                            <?php PrintProgressBarAdvanced ($AvgRating['EducationalGrants'],0,5,'','info');?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <span>
                                                Acceptance Rate
                                                <br />
                                            </span>
                                            <?php PrintProgressBarAdvanced ($AvgRating['AcceptanceRate'],0,5,'','info');?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <span>
                                                Student-faculty ratio
                                                <br />
                                            </span>
                                            <?php PrintProgressBarAdvanced ($AvgRating['StudentFacultyRatio'],0,5,'','info');?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <span>Technical labs and library</span>
                                            <?php PrintProgressBarAdvanced ($AvgRating['LabsAndLibrary'],0,5,'','info');?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <span>Class size index</span>
                                            <?php PrintProgressBarAdvanced ($AvgRating['ClassSizeIndex'],0,5,'','info');?>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <p>
                            <?php echo $Record['Description']; ?>
                        </p>
                        <h6 class="text-muted d-xl-flex align-items-xl-center mb-2">
                            <img src="assets/img/location.png" style="width: 36px;margin-right: 20px;" />Address - <?php echo $Record['Address']; ?>
                        </h6>
                        <h6 class="text-muted mb-2">
                            <img src="assets/img/phone.png" style="width: 36px;margin-right: 20px;" /> Contacts - <?php echo $Record['ContactNumber']; ?>
                        </h6>
                        
                        <div role="group" class="btn-group">
                       
                            <a class="btn btn-info <?php if($FacultyCount==0)echo "disabled"; ?>" href="CollegeFacultyList.php?CID=<?php echo $Record['CID']; ?>">
                                View Faculties - <?php echo $FacultyCount; ?>
                            </a>
                            
                            <?php if(isset($_SESSION['UID']) ){ ?>

                            <?php if(($_SESSION['User']['UserType'] == 'Student' || $_SESSION['User']['UserType'] == 'Parent') && $_SESSION['User']['CID'] == $ID){ ?>
                            
                            <button class="btn btn-primary" ng-click="SetShowPanel('AddReview')" type="button">Write Reviews</button>
                            
                            <?php } ?>
                            <?php }else{ ?>
                            <a class="btn btn-danger" href="login.php">Login to Write Review</a>
                            <?php } ?>

                            

                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php if($Reviews->num_rows>0){ ?>
    <div class="container" ng-show="ShowPanel=='Details'">

        <div class="card shadow-sm">
            <div class="card-header">
                <h5 class="mb-0">Reviews</h5>
            </div>
            <div class="table-responsive">
                <table class="table">
                    <tbody>

                        <?php if($Reviews->num_rows>0)while($row= $Reviews->fetch_assoc())
                                  {
                        ?>
                        <tr>
                            <td class="text-center" style="width: 124px;">
                                <?php  if ($row["ReviewType"]=="Anonymous"){ ?>
                                <img class="rounded-circle border rounded border-white shadow" src="assets/img/avatar_2x.png" style="max-width: 99px;" />
                                <?php } else {
                                           PrintImage("assets/img/". $row["UID"].".png","assets/img/avatar_2x.png",100,100); } ?>

                            </td>
                            <td>
                                <div class="row">
                                    <div class="col">
                                        <?php  if ($row["ReviewType"]=="Anonymous"){ ?>
                                        <h6>
                                            Anonymous - ( <?php echo $row["UserType"]; ?> )
                                        </h6>
                                        <?php } else { ?>
                                        <h6>
                                            <?php echo $row["UserName"]; ?>
                                        </h6>
                                        <?php  } ?>


                                    </div>
                                    <?php if(isset($_SESSION["UID"]) && $_SESSION["UID"] == $row["UID"]){ ?>

                                    <div class="col-auto">
                                        <a class="btn btn-danger" onclick="return confirm('Are you sure');" href="viewcollege.php?DeleteReview=<?php echo $row["CRID"]; ?>&CID=<?php echo $row["CID"]; ?>">
                                            <i class="fa fa-remove"></i>
                                        </a>
                                    </div>
                                    <?php  } ?>
                                </div>

                                <p class="text-secondary" style="font-size: 13px;margin-bottom: 8px;">
                                    <i class="fa fa-calendar" style="margin-right: 13px;"></i>
                                    <strong>
                                        <?php echo $row["ReviewDateTime"]; ?>
                                    </strong>
                                </p>
                                <p>
                                    <?php echo $row["Review"]; ?>
                                </p>
                            </td>
                        </tr>
                        <?php } else {  PrintAlert("No Record Found","Danger"); } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php } ?>
    <div class="container" style="margin-top: 19px;" ng-show="ShowPanel=='AddReview'">
        <div class="card shadow-sm">
            <div class="card-header">
                <h5 class="mb-0">Add a review</h5>
            </div>
            <div class="card-body">
                <form>
                    <div class="form-row">
                        <div class="col">
                            <div class="form-group">
                                <p style="margin-bottom: 3px;font-size: 14px;">Placement percent</p>
                                <nav>
                                    <ul class="pagination">
                                        <li class="page-item" ng-class="Review.PlacementPercent==1?'Active':''"  ng-click="SetPlacementPercent(1)">
                                            <a class="page-link">1</a>
                                        </li>
                                        <li class="page-item" ng-class="Review.PlacementPercent==2?'Active':''"  ng-click="SetPlacementPercent(2)">
                                            <a class="page-link">2</a>
                                        </li>
                                        <li class="page-item" ng-class="Review.PlacementPercent==3?'Active':''"  ng-click="SetPlacementPercent(3)">
                                            <a class="page-link">3</a>
                                        </li>
                                        <li class="page-item" ng-class="Review.PlacementPercent==4?'Active':''"  ng-click="SetPlacementPercent(4)">
                                            <a class="page-link">4</a>
                                        </li>
                                        <li class="page-item" ng-class="Review.PlacementPercent==5?'Active':''"  ng-click="SetPlacementPercent(5)">
                                            <a class="page-link">5</a>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <p style="margin-bottom: 3px;font-size: 14px;">Fee Structure</p>
                                <nav>
                                    <ul class="pagination">
                                        <li class="page-item" ng-class="Review.FeeStructure==1?'Active':''"  ng-click="SetFeeStructure(1)">
                                            <a class="page-link">1</a>
                                        </li>
                                        <li class="page-item" ng-class="Review.FeeStructure==2?'Active':''"  ng-click="SetFeeStructure(2)">
                                            <a class="page-link">2</a>
                                        </li>
                                        <li class="page-item" ng-class="Review.FeeStructure==3?'Active':''"  ng-click="SetFeeStructure(3)">
                                            <a class="page-link">3</a>
                                        </li>
                                        <li class="page-item" ng-class="Review.FeeStructure==4?'Active':''"  ng-click="SetFeeStructure(4)">
                                            <a class="page-link">4</a>
                                        </li>
                                        <li class="page-item" ng-class="Review.FeeStructure==5?'Active':''"  ng-click="SetFeeStructure(5)">
                                            <a class="page-link">5</a>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="col">
                            <div class="form-group">
                                <p style="margin-bottom: 3px;font-size: 14px;">
                                    Educational grants on academic performance
                                    <br />
                                </p>
                                <nav>
                                    <ul class="pagination">
                                        <li class="page-item" ng-class="Review.EducationalGrants==1?'Active':''"  ng-click="SetEducationalGrants(1)">
                                            <a class="page-link">1</a>
                                        </li>
                                        <li class="page-item" ng-class="Review.EducationalGrants==2?'Active':''"  ng-click="SetEducationalGrants(2)">
                                            <a class="page-link">2</a>
                                        </li>
                                        <li class="page-item" ng-class="Review.EducationalGrants==3?'Active':''"  ng-click="SetEducationalGrants(3)">
                                            <a class="page-link">3</a>
                                        </li>
                                        <li class="page-item" ng-class="Review.EducationalGrants==4?'Active':''"  ng-click="SetEducationalGrants(4)">
                                            <a class="page-link">4</a>
                                        </li>
                                        <li class="page-item" ng-class="Review.EducationalGrants==5?'Active':''"  ng-click="SetEducationalGrants(5)">
                                            <a class="page-link">5</a>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <p style="margin-bottom: 3px;font-size: 14px;">Acceptance Rate</p>
                                <nav>
                                    <ul class="pagination">
                                        <li class="page-item" ng-class="Review.AcceptanceRate==1?'Active':''"  ng-click="SetAcceptanceRate(1)">
                                            <a class="page-link">1</a>
                                        </li>
                                        <li class="page-item" ng-class="Review.AcceptanceRate==2?'Active':''"  ng-click="SetAcceptanceRate(2)">
                                            <a class="page-link">2</a>
                                        </li>
                                        <li class="page-item" ng-class="Review.AcceptanceRate==3?'Active':''"  ng-click="SetAcceptanceRate(3)">
                                            <a class="page-link">3</a>
                                        </li>
                                        <li class="page-item" ng-class="Review.AcceptanceRate==4?'Active':''"  ng-click="SetAcceptanceRate(4)">
                                            <a class="page-link">4</a>
                                        </li>
                                        <li class="page-item" ng-class="Review.AcceptanceRate==5?'Active':''"  ng-click="SetAcceptanceRate(5)">
                                            <a class="page-link">5</a>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="col">
                            <div class="form-group">
                                <p style="margin-bottom: 3px;font-size: 14px;">Student-faculty ratio</p>
                                <nav>
                                    <ul class="pagination">
                                        <li class="page-item" ng-class="Review.StudentFacultyRatio==1?'Active':''"  ng-click="SetStudentFacultyRatio(1)">
                                            <a class="page-link">1</a>
                                        </li>
                                        <li class="page-item" ng-class="Review.StudentFacultyRatio==2?'Active':''"  ng-click="SetStudentFacultyRatio(2)">
                                            <a class="page-link">2</a>
                                        </li>
                                        <li class="page-item" ng-class="Review.StudentFacultyRatio==3?'Active':''"  ng-click="SetStudentFacultyRatio(3)">
                                            <a class="page-link">3</a>
                                        </li>
                                        <li class="page-item" ng-class="Review.StudentFacultyRatio==4?'Active':''"  ng-click="SetStudentFacultyRatio(4)">
                                            <a class="page-link">4</a>
                                        </li>
                                        <li class="page-item" ng-class="Review.StudentFacultyRatio==5?'Active':''"  ng-click="SetStudentFacultyRatio(5)">
                                            <a class="page-link">5</a>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <p style="margin-bottom: 3px;font-size: 14px;">Technical labs and library</p>
                                <nav>
                                    <ul class="pagination">
                                        <li class="page-item" ng-class="Review.LabsAndLibrary==1?'Active':''" ng-click="SetLabsAndLibrary(1)">
                                            <a class="page-link">1</a>
                                        </li>
                                        <li class="page-item" ng-class="Review.LabsAndLibrary==2?'Active':''" ng-click="SetLabsAndLibrary(2)">
                                            <a class="page-link">2</a>
                                        </li>
                                        <li class="page-item" ng-class="Review.LabsAndLibrary==3?'Active':''" ng-click="SetLabsAndLibrary(3)">
                                            <a class="page-link">3</a>
                                        </li>
                                        <li class="page-item" ng-class="Review.LabsAndLibrary==4?'Active':''" ng-click="SetLabsAndLibrary(4)">
                                            <a class="page-link">4</a>
                                        </li>
                                        <li class="page-item" ng-class="Review.LabsAndLibrary==5?'Active':''" ng-click="SetLabsAndLibrary(5)">
                                            <a class="page-link">5</a>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <p style="margin-bottom: 3px;font-size: 14px;">Class size index</p>
                        <nav>
                            <ul class="pagination">
                                <li class="page-item" ng-class="Review.ClassSizeIndex==1?'Active':''" ng-click="SetClassSizeIndex(1)">
                                    <a class="page-link">1</a>
                                </li>
                                <li class="page-item" ng-class="Review.ClassSizeIndex==2?'Active':''" ng-click="SetClassSizeIndex(2)">
                                    <a class="page-link">2</a>
                                </li>
                                <li class="page-item" ng-class="Review.ClassSizeIndex==3?'Active':''" ng-click="SetClassSizeIndex(3)">
                                    <a class="page-link">3</a>
                                </li>
                                <li class="page-item" ng-class="Review.ClassSizeIndex==4?'Active':''" ng-click="SetClassSizeIndex(4)">
                                    <a class="page-link">4</a>
                                </li>
                                <li class="page-item" ng-class="Review.ClassSizeIndex==5?'Active':''" ng-click="SetClassSizeIndex(5)">
                                    <a class="page-link">5</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                    <div class="form-group">
                        <textarea class="form-control" rows="4" placeholder="Write a review" ng-model="Review.Review" name="Review"></textarea>
                    </div>
                 
                    <div class="form-row">
                        <div class="col">

                            <div class="custom-control custom-switch">
                                <input type="checkbox" ng-model="Review.Anonymous" class="custom-control-input" id="formCheck-1" />
                                <label class="custom-control-label" for="formCheck-1">Anonymous</label>
                            </div>
                        </div>
                        <div class="col">
                            <div role="group" class="btn-group">
                                <button class="btn btn-secondary" ng-click="SetShowPanel('Details')" type="button">Cancel</button>
                                <button class="btn btn-success" ng-click="CreateReview()" type="button">Create</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/bs-init.js"></script>
</body>

</html>