<?php
session_start();

$err=$State=$Keyword="";
include('assets/phpscript/FormatedOutput.php');
include('assets/Database/DBMySql.php');
$db=new DBMySql;
$ID=1;
if(isset($_GET["CID"])){$ID=$_GET["CID"];}

$Keyword="";
if(isset($_GET["Keyword"])){    $Keyword=$_GET["Keyword"];}
$sql="SELECT * FROM faculties where CID=".$ID." and (FacultyName like '%".$Keyword."%' or Designation like '%".$Keyword."%')  ORDER BY Rating DESC";
$Records = $db->GetResult($sql);



?>


<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Review Hub</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <script>
        function Search() {
            var state = $('#StateList').val();
            location.assign("search.php?State=" + state);
        }
    </script>
</head>

<body>
    <?php include('menu.php'); ?>
    <div class="container d-xl-flex align-items-xl-center" style="margin-top: 80px;">
        <h4 class="text-secondary flex-fill">College Faculties </h4>
        <form>
            <input hidden name="CID" value="<?php echo $ID;?>" />
        <div class="input-group" style="width: 433px;">
            <div class="input-group-prepend">
                <span class="input-group-text">
                    <i class="fa fa-search"></i>
                </span>
            </div>
            
            <input name="Keyword" type="search" value="<?php echo $Keyword;?>" class="form-control" placeholder="Faculty Name / Department" />
            <div class="input-group-append">
                <button class="btn btn-primary" type="submit">Go!</button>
            </div>
        </div>
        </form>
    </div>
    <hr />
    
    <div class="container" style="margin-top: 19px;">
        <div class="table-responsive table-bordered border rounded">
            <table class="table table-striped table-bordered table-hover">
                <tbody>
                    <?php if($Records)while($row= $Records->fetch_assoc())
                        {
                    ?>
                    <tr>
                        <td class="text-center" style="width: 277px;">
                            <img class="rounded-circle border shadow" src="assets/img/Faculties/<?php echo $row["FID"]; ?>.png" style="max-width: 200px;" />
                        </td>
                        <td>
                            <div class="col">
                                <h4><?php echo $row["FacultyName"]; ?></h4>
                                <hr />
                                <h4 class="text-warning mb-2">
                                    <i class="fa fa-star"></i> Rating - <?php echo round( $row["Rating"],1); ?>
                                </h4>
                                <h6 class="text-info d-xl-flex align-items-xl-center mb-2">
                                    <img class="mr-5" src="assets/img/Users Student Filled.png" style="width: 36px;" /> <?php echo $row["Designation"]; ?>
                                </h6>
                                <a class="btn btn-secondary" href="viewFaculty.php?FID=<?php echo $row["FID"]; ?>">View Profile / Reviews</a>
                            </div>
                        </td>
                    </tr>
                    <?php } ?>
                   
                  
                </tbody>
            </table>
        </div>
    </div>
    
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/bs-init.js"></script>
</body>

</html>