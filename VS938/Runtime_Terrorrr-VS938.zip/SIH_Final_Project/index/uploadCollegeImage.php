<?php
session_start();
$folderPath = 'assets/img/Colleges/';
$blob= (file_get_contents('php://input'));
include('assets/Database/DBMySql.php'); $db=new DBMySql;
$ID=1;
$CID = $db->ScalerQuery("select CID from colleges where UID = ".$_SESSION["UID"]);
if(isset($CID))$ID=$CID;
$image_parts = explode(";base64,", $_POST['image']);
$image_type_aux = explode("image/", $image_parts[0]);
$image_type = $image_type_aux[1];
$image_base64 = base64_decode($image_parts[1]);
$file = $folderPath . $ID . '.png';
file_put_contents($file, $image_base64);
echo json_encode(["image uploaded successfully."]);
?>