<?php
session_start();
include_once('../Database/DBMySql.php');$db=new DBMySql;
$KidID=0;
$SQL="SELECT * from families where CID=0";
if(isset($_GET['KidID'])){
    $KidID=$_GET['KidID'];
}
$SQL="SELECT * from users where KidID=".$KidID;


$result=$db->GetResult($SQL);
$myArray = array();
if($result)while($row = $result->fetch_assoc())
{
    $myArray[] = $row;
}
//shuffle($myArray);
echo json_encode($myArray);


?>