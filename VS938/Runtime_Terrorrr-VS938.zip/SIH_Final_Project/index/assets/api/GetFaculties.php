<?php
session_start();
include_once('../Database/DBMySql.php');$db=new DBMySql;
$CID=1;
$SQL="SELECT * from faculties";

if(isset($_SESSION['UID'])){
    $CID = $db->ScalerQuery("select CID from colleges where UID=".($_SESSION['UID']));
    $SQL="SELECT * from faculties where CID=".$CID;

}



$result=$db->GetResult($SQL);
$myArray = array();
if($result)while($row = $result->fetch_assoc())
{
    $myArray[] = $row;
}
//shuffle($myArray);
echo json_encode($myArray);


?>