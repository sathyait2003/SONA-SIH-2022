<?php


include_once('../Database/DBMySql.php');$db=new DBMySql;

$FID=1;
if(isset($_GET["FID"]))$FID.$_GET["FID"];
$sql="SELECT AVG(`Rating`) AS `Rating`,AVG(`Preparedness`) AS `Preparedness`,AVG(`Explaination`) AS `Explaination`,AVG(`TeachingAids`) AS `TeachingAids`,AVG(`Availability`) AS `Availability`,AVG(`Discussion`) AS `Discussion`,AVG(`Examples`) AS `Examples` FROM `faculty_reviews` INNER JOIN  faculties on faculty_reviews.FID = faculties.FID ";

$result=$db->GetResult($sql);
$myArray = array();
if($result)
{
    while($row = $result->fetch_assoc()){ $myArray[] = $row;}
    $Response["Status"]='Success';
    $Response["Data"]=$myArray;
    echo json_encode($Response);return;
}

else{
    $Response["Status"]='Error';
    $Response["Message"]='Invalid Parameters';
    echo json_encode($Response);return;
}

?>
1. 
