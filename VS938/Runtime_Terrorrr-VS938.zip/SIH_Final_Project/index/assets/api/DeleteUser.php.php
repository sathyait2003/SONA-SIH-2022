<?php

if(session_status()==1){session_start();}
$Name=$Mobile=$Email=$PWD=$Address=$CID=$Course=$CID="";
include('../Database/DBMySql.php'); $db=new DBMySql;


$UID = "0";if(isset($_GET["UID"])) $UID=$_GET["UID"];
if(isset($_GET["UID"])){
    $sql="DELETE from users where UID='".$_GET["UID"]."'";
    $result=$db->NonQuery($sql);
    $Response["Status"]='Success';
    $Response["Message"]='Record Deleted';
    echo json_encode($Response);
}


?>