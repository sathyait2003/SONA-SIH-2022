<?PHP
if(session_status()==1){session_start();}
$Name=$Mobile=$Email=$PWD=$Address=$CID=$Course=$CID="";
include('../Database/DBMySql.php'); $db=new DBMySql;


$UID = "0";if(isset($_GET["UID"])) $UID=$_GET["UID"];
//$FMID = "1";if(isset($_SESSION["FMID"])) $CID=$_GET["FMID"];


$Name=$_GET["Name"];
$Mobile=$_GET["Mobile"];
$Email=$_GET["Email"];
$KidID=$_GET["KidID"];
$CID = 1;if(isset($_SESSION["User"]["CID"]))$CID = $_SESSION["User"]["CID"];

$Designation=$_GET["Designation"];

    if($UID!="0")
    {
        if($db->ScalerQuery("select count(*) from users where UID<>".$UID." AND Mobile='".$Mobile."'")=="1")  {$Response["Status"]='Error';$Response["Message"]='Mobile Already Exist.';}
        else
        {
            $sql="Update users set `UserName`='".$Name."',`Mobile`='".$Mobile."',Email='".$Email."' where UID=".$UID;
            if($db->NonQuery($sql))
            {
                $Response["Status"]='Success';
                $Response["Message"]='Information Updated';
            }
            else{$Response["Status"]='Error';$Response["Message"]=$sql;}
        }
    }
    else{
        if($db->ScalerQuery("select count(*) from users where Mobile='".$Mobile."'")=="1")  {$Response["Status"]='Error';$Response["Message"]='Mobile Already Exist.';}
        else if($db->ScalerQuery("select count(*) from users where Email='".$Email."'")=="1")  {$Response["Status"]='Error';$Response["Message"]='Email Already Exist.';}
        else
        {
            $sql="INSERT INTO users(`UserName`,`Mobile`,PWD,CreatedOn,Email,KidID,CID,UserType,Status) VALUES('".$Name."','".$Mobile."','".$Mobile."',NOW(),'".$Email."','".$KidID."',".$CID.",'Parent','Approved');";
            if($db->NonQuery($sql))
            {
                $_SESSION["UID"]=$db->NonQuery("select MAX(UID) from users");
                $Response["Status"]='Success';
                $Response["Message"]='User Added.';
            }
            else{
                $Response["Status"]='Error';$Response["Message"]=$sql;
            }
        }

    }//else{$Response["Status"]='Error';$Response["Message"]='Invalid User';}


echo json_encode($Response);

?>