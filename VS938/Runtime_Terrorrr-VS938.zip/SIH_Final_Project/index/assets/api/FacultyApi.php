<?PHP
if(session_status()==1){session_start();}
$Name=$CID=$Email=$PWD=$Address=$CID=$Designation=$CID="";
include('../Database/DBMySql.php'); $db=new DBMySql;


$FID = "0";if(isset($_GET["FID"])) $FID=$_GET["FID"];
$CID = "1";
if(isset($_SESSION["UID"])){$CID=$db->ScalerQuery("select CID from colleges where UID=".$_SESSION["UID"]);}



$Name=$_GET["Name"];
$Designation=$_GET["Designation"];
$Course=$_GET["Course"];


    if($FID!="0")
    {
        $sql="Update faculties set `FacultyName`='".$Name."',Designation='".$Designation."',Course='".$Course."' where FID=".$FID;
        if($db->NonQuery($sql))
        {
            $Response["Status"]='Success';
            $Response["Message"]='Information Updated';
        }
        else{$Response["Status"]='Error';$Response["Message"]=$sql;}
    }
    else{
        $sql="INSERT INTO faculties(`FacultyName`,`CID`,Designation,Course) VALUES('".$Name."',".$CID.",'".$Designation."','".$Course."');";
        if($db->NonQuery($sql))
        {
            $_SESSION["FID"]=$db->NonQuery("select MAX(FID) from faculties");
            $Response["Status"]='Success';
            $Response["Message"]='Record Added.';
        }
        else{
            $Response["Status"]='Error';$Response["Message"]=$sql;
        }
    }//else{$Response["Status"]='Error';$Response["Message"]='Invalid User';}


echo json_encode($Response);

?>