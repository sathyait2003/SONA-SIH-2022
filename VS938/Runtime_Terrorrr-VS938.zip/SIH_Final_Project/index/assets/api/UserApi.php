<?PHP
if(session_status()==1){session_start();}
$Name=$Mobile=$Email=$PWD=$Address=$CID=$Course=$CID="";
include('../Database/DBMySql.php'); $db=new DBMySql;


$UID = "0";if(isset($_GET["UID"])) $UID=$_GET["UID"];
$CID = "1";if(isset($_SESSION["CID"])) $CID=$_GET["CID"];


$Name=$_GET["Name"];
$Mobile=$_GET["Mobile"];
$Email=$_GET["Email"];
$Course=$_GET["Course"];

$UserType="Student";if(isset($_GET["UserType"]))$UserType=$_GET["UserType"];
$CID = 1;if(isset($_SESSION["User"]["CID"]))$CID = $_SESSION["User"]["CID"];
$Designation="";if(isset($_GET["Designation"]))$Designation=$_GET["Designation"];
$Status="Pending";if(isset($_GET["Status"]))$Status=$_GET["Status"];

    if($UID!="0")
    {
        if($db->ScalerQuery("select count(*) from users where UID<>".$UID." AND Mobile='".$Mobile."'")=="1")  {$Response["Status"]='Error';$Response["Message"]='Mobile Already Exist.';}
        else if($db->ScalerQuery("select count(*) from users where UID<>".$UID." AND Email='".$Email."'")=="1")  {$Response["Status"]='Error';$Response["Message"]='Email Already Exist.';}
        else
        {
            $sql="Update users set `UserName`='".$Name."',`Mobile`='".$Mobile."',Course='".$Course."',Email='".$Email."' where UID=".$UID;
            if($db->NonQuery($sql))
            {
                $Response["Status"]='Success';
                $Response["Message"]='Information Updated';
            }
            else{$Response["Status"]='Error';$Response["Message"]=$sql;}
        }
    }
    else{
        if($db->ScalerQuery("select count(*) from users where Mobile='".$Mobile."'")=="1")  {$Response["Status"]='Error';$Response["Message"]='Mobile Already Exist.';}
        else if($db->ScalerQuery("select count(*) from users where Email='".$Email."'")=="1")  {$Response["Status"]='Error';$Response["Message"]='Email Already Exist.';}
        else
        {
            $sql="INSERT INTO users(`UserName`,`Mobile`,PWD,CreatedOn,Email,Course,CID,UserType,Status) VALUES('".$Name."','".$Mobile."','".$Mobile."',NOW(),'".$Email."','".$Course."',".$CID.",'".$UserType."','".$Status."');";
            if($db->NonQuery($sql))
            {
                //$_SESSION["UID"]=$db->ScalerQuery("select MAX(UID) from users");
                $Response["Status"]='Success';
                $Response["Message"]='User Added.';
            }
            else{
                $Response["Status"]='Error';$Response["Message"]=$sql;
            }
        }

    }//else{$Response["Status"]='Error';$Response["Message"]='Invalid User';}


echo json_encode($Response);

?>