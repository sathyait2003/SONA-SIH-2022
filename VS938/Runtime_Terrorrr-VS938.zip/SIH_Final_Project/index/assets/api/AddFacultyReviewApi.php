





<?php
session_start();
include_once('../Database/DBMySql.php');$db=new DBMySql;
$data =json_decode( file_get_contents("php://input"));


$Preparedness=$data->Preparedness;
$Explaination=$data->Explaination;
$TeachingAids=$data->TeachingAids;
$Availability=$data->Availability;
$Discussion=$data->Discussion;
$Examples=$data->Examples;
$FID=$data->FID;
$Review=$data->Review;
$ReviewType="Normal";if($data->Anonymous)$ReviewType="Anonymous";
// $Rating = ($Preparedness+$Explaination+$TeachingAids+$Availability+$Discussion+$Examples)/6;
$Rating = ($Preparedness*0.25+$Explaination*0.30+$TeachingAids*0.15+$Availability*0.05+$Discussion*0.10+$Examples*0.15);


$UID = "1";if(isset($_SESSION["UID"])) $UID=$_SESSION["UID"];
$cn=$db->GetActiveConnection();
$FRID = $db->ScalerQueryOnConnection("SELECT IFNULL(MAX(FRID),0) FROM `faculty_reviews` WHERE FID=".$FID." AND UID=".$UID." LIMIT 0,1;",$cn);


if($FRID==0)
{
    $sql="INSERT INTO `faculty_reviews`(`Review`,`Preparedness`,`Explaination`,`TeachingAids`,`Availability`,`Discussion`,`Examples`,Rating,`FID`,`UID`,`ReviewDateTime`,ReviewType) VALUES('".$Review."',".$Preparedness.",".$Explaination.",".$TeachingAids.",".$Availability.",".$Discussion.",".$Examples.",".$Rating.",".$FID.",".$UID.",NOW(),'".$ReviewType."');";
    $db->NonQueryOnConnection($sql,$cn);

}
else{
    $sql="UPDATE `faculty_reviews` set `Review`='".$Review."',`Preparedness`=".$Preparedness.",`Explaination`=".$Explaination.",`TeachingAids`=".$TeachingAids.",`Availability`=".$Availability.",`Discussion`=".$Discussion.",`Examples`=".$Examples.",Rating=".$Rating.",`ReviewDateTime`=NOW(),ReviewType='".$ReviewType."' where FRID=".$FRID;

    $db->NonQueryOnConnection($sql,$cn);
}
$FinalRating = $db->ScalerQuery("SELECT AVG(Rating) FROM `faculty_reviews` WHERE FID=".$FID);
    $db->NonQuery("Update faculties set Rating=".$FinalRating." where FID=".$FID);
    $cn->close();


    $Response["Status"]='Success';

    echo json_encode($Response);return;



?>