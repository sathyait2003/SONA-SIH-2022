<?php
session_start();
include_once('../Database/DBMySql.php');$db=new DBMySql;

$SQL="SELECT * from users where UserType='Representative'";


$result=$db->GetResult($SQL);
$myArray = array();
if($result)while($row = $result->fetch_assoc())
    {
        $myArray[] = $row;
    }
//shuffle($myArray);
echo json_encode($myArray);


?>