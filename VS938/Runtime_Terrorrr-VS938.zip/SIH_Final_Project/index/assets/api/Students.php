<?php

/**
 * Students short summary.
 *
 * Students description.
 *
 * @version 1.0
 * @author Rishi
 */
class Students
{
}