<?php
session_start();
    include_once('../Database/DBMySql.php');$db=new DBMySql;


    $sql="select * from products";
if(isset($_GET["ProductName"]))$sql="select * from products where ProductName like '%".$_GET["ProductName"]."%'";
if(isset($_GET["PID"]))$sql="select * from products where PID=".$_GET["PID"];
if(isset($_GET["Category"]))$sql="select * from products where Category = '".$_GET["Category"]."'";
if(isset($_GET["SubCategory"]))$sql="select * from products where SubCategory = '".$_GET["SubCategory"]."'";


$result=$db->GetResult($sql);

$myArray = array();
while($row = $result->fetch_assoc())
{
    $row['Quantity']=1;
    $myArray[] = $row;
}

if($result){
    $Response["Status"]='Success';
    $Response["Data"]=$myArray;
    echo json_encode($Response);return;
}
else{
    $Response["Status"]='Error';
    $Response["Message"]='Invalid Parameters';
    echo json_encode($Response);return;
}




?>