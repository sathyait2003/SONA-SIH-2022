<?php
session_start();
include_once('../Database/DBMySql.php');$db=new DBMySql;
$PostData =json_decode(file_get_contents("php://input"));
//echo json_encode($PostData);return;
$flag=true;
$UID=1;if(isset($_SESSION['UID'])) $UID=$_SESSION['UID'];
//if(!isset($_SESSION["UID"])){echo 'Error';return;}
//$UID=$_SESSION["UID"];
$BillAmount=$PostData->BillAmount;
//$ShopId = $PostData[0]->UID;
$con=$db->GetActiveConnection();
$OrderNumber =100001 ;
if($db->ScalerQueryOnConnection("select COUNT(*) from orders",$con)>0)$OrderNumber=$db->ScalerQueryOnConnection("SELECT MAX(OrderNumber)+1 FROM orders",$con);
foreach($PostData->Products as $order)
{
    $db->NonQueryOnConnection("INSERT INTO `orderinfo`(`ProductID`,`Quantity`,`Price`,`OrderNumber`,`TotalPrice`) VALUES(".$order->PID.",".$order->Quantity.",".$order->Price.",".$OrderNumber.",".($order->Quantity*$order->Price).")",$con);
}
$sql = "INSERT INTO `orders`(`OrderNumber`,`OrderDate`,`BillAmount`,`UID`) VALUES (".$OrderNumber.",NOW(),".$BillAmount.",".$UID.");";

if($db->NonQueryOnConnection($sql,$con))
{
    $Response["Status"]='Success';
    $Response["Message"]="Order Placed Successfully";
}
else{
    $Response["Status"]='Error';
    $Response["Message"]=$sql;
}
$con->close();
echo json_encode($Response);

?>