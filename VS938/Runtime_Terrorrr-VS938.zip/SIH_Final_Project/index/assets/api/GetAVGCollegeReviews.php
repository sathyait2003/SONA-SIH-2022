<?php


include_once('../Database/DBMySql.php');$db=new DBMySql;

$CID=1;
if(isset($_GET["CID"]))$CID.$_GET["UID"];
$sql="SELECT AVG(`Review`),AVG(`PlacementPercent`),AVG(`FeeStructure`),AVG(`EducationalGrants`),AVG(`AcceptanceRate`),AVG(`StudentFacultyRatio`),AVG(`LabsAndLibrary`),AVG(`ClassSizeIndex`) FROM `college_reviews` WHERE CID=".$CID;

$result=$db->GetResult($sql);
$myArray = array();
if($result)
{
    while($row = $result->fetch_assoc()){ $myArray[] = $row;}
    $Response["Status"]='Success';
    $Response["Data"]=$myArray;
    echo json_encode($Response);return;
}

else{
    $Response["Status"]='Error';
    $Response["Message"]='Invalid Parameters';
    echo json_encode($Response);return;
}

?>