<?php
session_start();
include_once('../Database/DBMySql.php');$db=new DBMySql;
$data =json_decode( file_get_contents("php://input"));

$PlacementPercent=$data->PlacementPercent;
$FeeStructure=$data->FeeStructure;
$EducationalGrants=$data->EducationalGrants;
$AcceptanceRate=$data->AcceptanceRate;
$StudentFacultyRatio=$data->StudentFacultyRatio;
$LabsAndLibrary=$data->LabsAndLibrary;
$ClassSizeIndex=$data->ClassSizeIndex;
$ReviewType="Normal";if($data->Anonymous)$ReviewType="Anonymous";
// $Rating = ($PlacementPercent+$FeeStructure+$EducationalGrants+$AcceptanceRate+$StudentFacultyRatio+$LabsAndLibrary+$ClassSizeIndex)/7;
$Rating = ($PlacementPercent*0.30+$FeeStructure*0.20+$EducationalGrants*0.20+$AcceptanceRate*0.10+$StudentFacultyRatio*0.10+$LabsAndLibrary*0.05+$ClassSizeIndex*0.05);

$Review=$data->Review;
$CID=$data->CID;
$UID = "0";if(isset($_SESSION["UID"])) $UID=$_SESSION["UID"];


$cn=$db->GetActiveConnection();

$CRID = $db->ScalerQueryOnConnection("SELECT IFNULL(MAX(CRID),0) FROM `college_reviews` WHERE CID=".$CID." AND UID=".$UID." LIMIT 0,1;",$cn);
if($CRID==0)
{
    $sql="INSERT INTO `college_reviews`(Review,Rating,`PlacementPercent`,`FeeStructure`,`EducationalGrants`,`AcceptanceRate`,`StudentFacultyRatio`,`LabsAndLibrary`,`ClassSizeIndex`,`CID`,`UID`,`ReviewDateTime`,ReviewType) VALUES('".$Review."',".$Rating.",".$PlacementPercent.",".$FeeStructure.",".$EducationalGrants.",".$AcceptanceRate.",".$StudentFacultyRatio.",".$LabsAndLibrary.",".$ClassSizeIndex.",".$CID.",".$UID.",NOW(),'".$ReviewType."');";
    $db->NonQueryOnConnection($sql,$cn);

}
else{
    $sql="Update `college_reviews` set Review='".$Review."',Rating=".$Rating.",`PlacementPercent`=".$PlacementPercent.",`FeeStructure`=".$FeeStructure.",`EducationalGrants`=".$EducationalGrants.",`AcceptanceRate`=".$AcceptanceRate.",`StudentFacultyRatio`=".$StudentFacultyRatio.",`LabsAndLibrary`=".$LabsAndLibrary.",`ClassSizeIndex`=".$ClassSizeIndex.",`ReviewDateTime`=NOW(),ReviewType='".$ReviewType."' where CRID=".$CRID;
    $db->NonQueryOnConnection($sql,$cn);
}
$FinalRating = $db->ScalerQueryOnConnection("SELECT AVG(Rating) FROM `college_reviews` WHERE CID=".$CID,$cn);
$db->NonQueryOnConnection("Update colleges set Rating=".$FinalRating." where CID=".$CID,$cn);


$cn->close();
$Response["Status"]='Success';
echo json_encode($Response);return;



?>