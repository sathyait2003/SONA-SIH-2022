<?php
session_start();
$folderPath = 'assets/img/Users/';
$blob= (file_get_contents('php://input'));

$UID=1;
if(isset($_POST["ID"]))$ID=$_POST["ID"];
$image_parts = explode(";base64,", $_POST['image']);
$image_type_aux = explode("image/", $image_parts[0]);
$image_type = $image_type_aux[1];
$image_base64 = base64_decode($image_parts[1]);
$file = $folderPath . $ID . '.png';
file_put_contents($file, $image_base64);
echo json_encode(["image uploaded successfully."]);
?>