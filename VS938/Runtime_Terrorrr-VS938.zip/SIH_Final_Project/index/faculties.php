<?php
session_start();
if(isset($_SESSION["UID"])){$UID=$_SESSION["UID"];}else{header("Login.php");return;}

include_once('assets/Database/DBMySql.php');$db=new DBMySql;
if(isset($_GET["Delete"])){$db->NonQuery("delete from faculties where FID=".$_GET["Delete"]);}
?>
<html>

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no" />
    <title>Review Hub</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css" />
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css" />
    <link rel="stylesheet" href="assets/fonts/fontawesome5-overrides.min.css" />
    <link rel="stylesheet" href="assets/css/Contact-Form-Clean.css" />
    <link rel="stylesheet" href="assets/css/Features-Boxed.css" />
    <link rel="stylesheet" href="assets/css/Features-Clean.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css" />
    <link rel="stylesheet" href="assets/css/Sidebar-Menu-1.css" />
    <link rel="stylesheet" href="assets/css/Sidebar-Menu.css" />
    <link rel="stylesheet" href="assets/css/styles.css" />
    <script src="assets/js/angular.min.js"></script>
    <script src="assets/js/angular-sanitize.min.js"></script>
<script src="assets/js/myjs.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.12/cropper.min.js" integrity="sha512-ooSWpxJsiXe6t4+PPjCgYmVfr1NS5QXJACcR/FPpsdm6kqG1FmQ2SVyg2RXeVuCRBLr0lWHnWJP6Zs1Efvxzww==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.12/cropper.min.css" integrity="sha512-0SPWAwpC/17yYyZ/4HSllgaK7/gg9OlVozq8K7rf3J8LvCjYEEIfzzpnA2/SSjpGIunCSD18r3UhvDcu/xncWA==" crossorigin="anonymous" referrerpolicy="no-referrer" />


    <style type="text/css">
        img {
            display: block;
            max-width: 100%;
        }
        .preview {
            overflow: hidden;
            width: 160px;
            height: 160px;
            margin: 10px;
            border: 1px solid red;
        }

    </style>
    <script>
        var app = angular.module('myApp', []);
        app.controller('customersCtrl', function ($scope, $http) {
            $scope.Record = { FID: 0 };
            $scope.Courses = ["CS","EC","EL","IT","ME","Civil"];
             var QueryString = QueryStringToJSON();
            $scope.Load = function () {
                $http.get("assets/api/GetFaculties.php?CID="+QueryString.CID).then(function (response) {
                    $scope.Records = response.data;
                    $scope.Records.forEach(Record => {

                            Record.ProfileImage = 'assets/img/Faculties/' + Record.FID + '.png?t=' + Date.now();

                        });
                console.log($scope.Records);
            });
            }
            $scope.Load();
            $scope.Save = function () {
                var Record = $scope.Record;
                $http.get("assets/api/FacultyApi.php?FID=" + Record.FID + "&Name=" + Record.FacultyName + "&Designation=" + Record.Designation + "&Course=" + Record.Course, Record).then(function (response) {
                    console.log(response.data);
                    $('#NewRecordModal').modal('hide');
                    $scope.Load();
                    $scope.Record= { FID: 0 };
            });
            }
            $scope.SetToEdit = function (Record) {
                console.log(Record); 
                $('#NewRecordModal').modal(); 
                $scope.Record = angular.copy(Record);
            }
            
           
        });

    </script>
</head>

<body ng-app="myApp" ng-controller="customersCtrl">
    <?php include("menu.php"); ?>
    <div id="wrapper" style="margin-top: 66px;">
        <div class="bg-dark shadow-sm" id="sidebar-wrapper">
            <?php include("sidemenu.php"); ?>
        </div>
        <div class="page-content-wrapper">
            <div class="page-content-wrapper">
               <div class="page-content-wrapper">
    <div class="container-fluid">
        <h1>Faculties</h1>
        <hr />
    </div>
    <div class="container-fluid">
        <div class="card">
            <div class="card-header">
                <div><a class="btn btn-dark" role="button" data-toggle="modal" href="#NewRecordModal">New Faculty</a>
                    <div class="modal fade" role="dialog" tabindex="-1" id="NewRecordModal">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h4>Add Update Record</h4><button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button></div>
                                <div class="modal-body">
                                    <form>
                                        <div class="form-group"><label>Name</label><input ng-model="Record.FacultyName" class="form-control" type="text" /></div>
                                        <div class="form-group"><label>Designation</label><input ng-model="Record.Designation" class="form-control" type="text" /></div>
                                        <div class="form-group">
                                            <label>Course</label>
                                            <select class="form-control" ng-model="Record.Course" >
                                            <option ng-repeat="x in Courses ">{{x}}</option>
                                            </select>
                                        </div>
                                    </form>
                                </div>
                                <div class="modal-footer">
                                    <button class="btn btn-light" data-dismiss="modal" type="button">Close</button>
                                    <button class="btn btn-primary" ng-click="Save()" type="button">Save</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th style="width: 50px;">Sn.</th>
                            <th class="text-center">Image</th>
                            <th>Browse</th>
                            <th>Name</th>
                            <th>Course</th>

                            <th>Designation</th>
                            <th class="text-center" style="width: 110px;">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr ng-repeat="Record in Records ">
                            <td>{{$index+1}}</td>
                            <td class="text-center" style="padding: 5px;width: 100px;">
                                <img ng-src="{{Record.ProfileImage}}" class="rounded" />

                            </td>
                            <td>
                                <input type="file" name="image" class="image" title="{{Record.FID}}" />
                            </td>
                            <td>{{Record.FacultyName}}</td>
                            <td>{{Record.Course}}</td>

                            <td>{{Record.Designation}}</td>
                            <td class="text-right">
                                <div class="btn-group" role="group">
                                    <button ng-click="SetToEdit(Record)" class="btn btn-info" type="button">
                                        <i class="fa fa-pencil"></i>
                                    </button>
                                    <a onclick="return confirm('Confirm Delete');" class="btn btn-danger" href="faculties.php?Delete={{Record.FID}}">
                                        <i class="fa fa-remove"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                       
                    </tbody>
                </table>
            </div>
        </div>
    </div>



    <div class="modal fade" id="modal" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
                            <div class="modal-dialog modal-lg" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="modalLabel">Crop image</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">�</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="img-container">
                                            <div class="row">
                                                <div class="col-md-8">
                                                    <!--  default image where we will set the src via jquery-->
                                                    <img id="image" class="img-fluid" />

                                                </div>
                                                <div class="col-md-4">
                                                    <div class="preview"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                        <button type="button" class="btn btn-primary" id="crop">Crop</button>
                                    </div>
                                </div>
                            </div>
                        </div>



    <hr />
</div>
            </div>
            <hr />
        </div>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/bs-init.js"></script>
    <script src="assets/js/Sidebar-Menu.js"></script>

    <script src="cropperjs/cropper.min.js" type="text/javascript"></script>
    <script>

    var bs_modal = $('#modal');
    var image = document.getElementById('image');
    var cropper,reader,file;

        var SelectedID = 0;
        $("body").on("change", ".image", function (e) {
            SelectedID=(e.target.title);
        var files = e.target.files;
        var done = function(url) {
            image.src = url;
            bs_modal.modal('show');
        };


        if (files && files.length > 0) {
            file = files[0];

            if (URL) {
                done(URL.createObjectURL(file));
            } else if (FileReader) {
                reader = new FileReader();
                reader.onload = function(e) {
                    done(reader.result);
                };
                reader.readAsDataURL(file);
            }
        }
    });

    bs_modal.on('shown.bs.modal', function() {
        cropper = new Cropper(image, {
            aspectRatio: 1,
            viewMode: 3,
            preview: '.preview'
        });
    }).on('hidden.bs.modal', function() {
        cropper.destroy();
        cropper = null;
    });

        $("#crop").click(function () {
            console.log(SelectedID);
        canvas = cropper.getCroppedCanvas({
            //width: 160,
            //height: 160,
        });
//        var context = canvas.getContext('2d');
//context.beginPath();
//      context.arc(width / 2, height / 2, Math.min(width, height) / 2, 0, 2 * Math.PI, true);
//      context.fill();
        canvas.toBlob(function(blob) {
            url = URL.createObjectURL(blob);
            var reader = new FileReader();
            reader.readAsDataURL(blob);
            reader.onloadend = function() {
                var base64data = reader.result;

                $.ajax({
                    type: "POST",
                    dataType: "json",
                    url: "uploadFacultyImage.php",
                    data: {image: base64data,ID:SelectedID},
                    success: function(data) {
                        bs_modal.modal('hide');
                        location.assign("Faculties.php");
                    }
                });
            };
        });
    });

    </script>
</body>

</html>