<?php
session_start();
$err=$State=$Keyword="";
include('assets/phpscript/FormatedOutput.php');
include('assets/Database/DBMySql.php');
$db=new DBMySql;

$sql="Select * from colleges order by Rating DESC limit 0,10";
$Records = $db->GetResult($sql);

?>


<html>

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no" />
    <title>Review Hub</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css" />
    <link rel="stylesheet" href="assets/css/Bootstrap-Payment-Form.css" />
    <link rel="stylesheet" href="assets/css/Google-Style-Login.css" />
    <link rel="stylesheet" href="assets/css/Hero-Technology.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css" />
    <link rel="stylesheet" href="assets/css/styles.css" />
<link href="assets/css/Features-Clean.css" rel="stylesheet" />
<link href="assets/css/Features-Boxed.css" rel="stylesheet" />
</head>

<body>
    <?php include('menu.php'); ?>

    <style type="text/css">
    
.carousel-inner img 
{
    width: 100%;
    height: 100vh;
   


   
}

.carousel-caption 
{
    position: absolute;
    top: 30%;
    text-transform: uppercase;
    text-align: center;
    
}

.carousel-caption h3 
{  color:black;
    font-size: 3em;
    font-weight: bold;
    font-style: italic;
    
}

.carousel-caption p
{
  color: black;
  font-weight: bold;
}


.carousel-control-prev
{
  
  bottom: 1%;

}

.carousel-control-next
{
  bottom: 1%;
}

</style>
    <!-- <div class="jumbotron hero-technology" style="margin-top:65px; height:700px">
        <h1 class="hero-title">Review Hub</h1>
        <p class="hero-subtitle">True Ratings for the students, by the students</p>
        <p>
            <a class="btn btn-primary btn-lg hero-button" role="button" href="search.php">Search College</a>
        </p>
    </div> -->

    <div id="demo" class="carousel slide carousel-fade" data-ride="carousel" data-interval="5000">
  
  <ul class="carousel-indicators">
    <li data-target="#demo" data-slide-to="0" class="active">
    </li>
    <li data-target="#demo" data-slide-to="1"></li>
    <li data-target="#demo" data-slide-to="2"></li>
    <li data-target="#demo" data-slide-to="3"></li>
  </ul>

  <div class="carousel-inner" >
    
    <div class="carousel-item active">
      <img src="image/i.jpg" >
      <div class="carousel-caption text-center">
        <h3> RATE IT TO MAKE IT</h3>
        <p> SHARE YOUR REVIEWS ON TEACHING LEARNING PROCESS</p>
        <a class="btn btn-success" role="button" href="search.php">Search College</a>
      </div>   
    </div>
    
    <div class="carousel-item">
      <img src="image/img_bg_2.jpg" >
      <div class="carousel-caption text-center">
        <h3>RATE IT TO MAKE IT</h3>
         <p> SHARE YOUR REVIEWS ON TEACHING LEARNING PROCESS</p>
        <a class="btn btn-success" role="button" href="search.php">Search College</a>
      </div>   
    </div>
    
    <div class="carousel-item">
      <img src="image/hero-background-technology.jpg" >
      <div class="carousel-caption text-center">
        <h3>RATE IT TO MAKE IT</h3>
         <p> SHARE YOUR REVIEWS ON TEACHING LEARNING PROCESS</p>
        <a class="btn btn-success" role="button" href="search.php">Search College</a>
      </div>   
    </div>

    <div class="carousel-item">
      <img src="image/i2.jpg" >
      <div class="carousel-caption text-center">
        <h3>RATE IT TO MAKE IT</h3>
         <p> SHARE YOUR REVIEWS ON TEACHING LEARNING PROCESS</p>
        <a class="btn btn-success" role="button" href="search.php">Search College</a>
      </div>   
    </div>
    
   
  </div>

  <a class="carousel-control-prev" href="#demo" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>
  
  <a class="carousel-control-next" href="#demo" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>

</div>
    <div class="features-boxed">
        <div class="container">
            <div class="intro">
                <h2 class="text-center">Top Ten Board </h2>
                <p class="text-center">Best Colleges according to User's Ratings</p>
            </div>
            <div class="row justify-content-center features">
                <?php if($Records->num_rows)while($row= $Records->fetch_assoc())
                    {
                ?>
                <div class="col-sm-6 col-md-5 col-lg-4 item">
                    <div class="box">
                        <div class="mb-2" style="width: 170px;height: 170px;margin-left: 60px;">
                            <img class="rounded img-fluid border shadow-sm" src="<?php echo "assets/img/Colleges/".$row["CID"].".png"; ?>" style="width: 170px;max-height: 170px;" />
                        </div>
                        <h3 class="name"><?php echo $row["CollegeName"]; ?></h3>
                        <p class="description"><?php echo $row["Description"]; ?></p>
                        <p class="description">
                            <?php echo "Rating - ", round( $row["Rating"],1); ?>
                        </p>
                        <a class="learn-more" href="viewcollege.php?CID=<?php echo $row["CID"]; ?>">Learn more »</a>
                    </div>
                </div>
                <?php }  ?>
            </div>
        </div>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/bs-init.js"></script>
</body>

</html>