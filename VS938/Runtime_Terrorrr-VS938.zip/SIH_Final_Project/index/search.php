<?php
session_start();

$err=$State=$Keyword="";
include('assets/phpscript/FormatedOutput.php');
include('assets/Database/DBMySql.php');
$db=new DBMySql;

$sql="Select * from colleges order by Rating DESC";
if(isset($_GET["State"])){
    $State=$_GET["State"];
    $sql="Select * from colleges WHERE State='".$State."' order by Rating DESC";
}
if(isset($_GET["Keyword"])){
    $Keyword=$_GET["Keyword"];
    $sql="Select * from colleges WHERE Address like '%".$Keyword."%' OR CollegeName like '%".$Keyword."%' order by Rating DESC";
}

$Records = $db->GetResult($sql);
$StateList = SelectOptionsFormArray( ["Select State -- ","Andaman and Nicobar Islands","Andhra Pradesh","Arunachal Pradesh","Assam","Bihar","Chandigarh","Chattisgarh","Daman and Diu","Delhi","Goa","Gujarat","Haryana","Himachal Pradesh","Jammu and Kashmir", "Jharkhand","Karnataka","Kerala","Ladakh","Lakshadweep","Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya", "Mizoram", "Nagaland","Odisha","Puducherry","Punjab","Rajashtan", "Sikkim", "Tamil Nadu", "Telangana", "Tripura" , "Uttarakhand","Uttar Pradesh", "West Bengal"],$State);




?>


<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Review Hub</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <script>
        function Search() {
            var state = $('#StateList').val();
            location.assign("search.php?State=" + state);
        }
    </script>
</head>

<body>
    <?php include('menu.php'); ?>
    

    <div class="container" style="margin-top: 80px;background-color:rgb(248 248 248)">
    <div class="card shadow bg-white">
        <div class="card-body">
            <div class="row">
                <div class="col d-xl-flex">
                    <h5 class="flex-fill mb-0">Select State</h5>
                    <select onchange="Search()" id="StateList" class="form-control" style="width: 294px;">
                        
                        <?php echo $StateList;?>
                        
                    </select>
                </div>
                <div class="col">
                <form>
                    <div class="input-group">
                        <div class="input-group-prepend"><span class="input-group-text"><strong>Or</strong></span></div>
                        <input class="form-control" value="<?php echo $Keyword; ?>" name="Keyword" type="text" placeholder="Enter Name / City" />
                        <div class="input-group-append"><button class="btn btn-primary" type="submit">Search</button></div>
                    </div>
                </form>
                    
            </div>
        </div>
    </div>
</div>
</div>
    <hr />
    <div class="container">
    <?php if($Records)while($row= $Records->fetch_assoc())
          {
              ?>
        <div class="card mb-4">
            <div class="card-body shadow-sm">
                <div class="row">
                    <div class="col">
                    <img class="border rounded shadow" src="<?php echo "assets/img/Colleges/".$row["CID"].".png"; ?>" style="max-width: 500px;" /></div>
                    <div class="col">
                        <h4><?php echo $row["CollegeName"]; ?></h4>
                        <hr />
                        <h4 class="text-warning mb-2"><i class="fa fa-star"></i> Rating - <?php echo round( $row["Rating"],1); ?></h4>
                        <p><?php echo $row["Description"]; ?></p>
                        <h6 class="text-muted mb-2">Address - <?php echo $row["Address"]; ?></h6>
                        <a class="btn btn-dark" href="viewcollege.php?CID=<?php echo $row['CID']; ?>" >View Details</a></div>
                </div>
            </div>
        </div>
         <?php } else {  PrintAlert("No Record Found","Danger"); } ?>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/bs-init.js"></script>
</body>

</html>