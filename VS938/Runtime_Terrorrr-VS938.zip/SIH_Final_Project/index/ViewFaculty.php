<?php
session_start();

$err=$State=$Keyword="";
include('assets/phpscript/FormatedOutput.php');
include('assets/Database/DBMySql.php');
$db=new DBMySql;
$ID=0;
if(isset($_GET["FID"])){ $ID=$_GET["FID"];}

if(isset($_GET["AddReview"])){

    $db->NonQueryOnConnection("INSERT INTO `faculty_reviews`(`Review`,`ReviewDateTime`,`FID`,`UID`) VALUES ('".$_GET["Review"]."',NOW(),".$ID.",".$_SESSION['UID'].")",$cn);
}

if(isset($_GET["DeleteReview"])){
    $cn=$db->GetActiveConnection();

    $db->NonQueryOnConnection("delete from faculty_reviews where FRID=".$_GET["DeleteReview"],$cn);
    $FinalRating = $db->ScalerQueryOnConnection("SELECT IFNULL(AVG(Rating),0) FROM `faculty_reviews` WHERE FID=".$ID,$cn);
    $db->NonQueryOnConnection("Update faculties set Rating=".$FinalRating." where FID=".$ID,$cn);
    $cn->close();
}



$sql="Select * from faculties where FID=".$ID;
$Record = $db->GetSingleRow($sql);

$sql="SELECT `FRID`,`Rating`,`Review`,`ReviewDateTime`,`FID`,u.`UID`,`UserName`,`UserType`,`Course`,ReviewType FROM `faculty_reviews` fr,users u  WHERE u.`UID`=fr.`UID` AND FID=".$ID;
$Reviews = $db->GetResult($sql);

$sql="SELECT AVG(`Rating`) AS `Rating`,AVG(`Preparedness`) AS `Preparedness`,AVG(`Explaination`) AS `Explaination`,AVG(`TeachingAids`) AS `TeachingAids`,AVG(`Availability`) AS `Availability`,AVG(`Discussion`) AS `Discussion`,AVG(`Examples`) AS `Examples` FROM `faculty_reviews` WHERE FID=".$ID;
$AvgRating=$db->GetSingleRow($sql);

$StateList = SelectOptionsFormArray( ["Delhi","Uttar Pradesh","Bihar"],$State);

?>


<html>

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no" />
    <title>Review Hub</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css" />
    <link rel="stylesheet" href="assets/css/styles.css" />
    <script src="assets/js/myjs.js"></script>
    <script src="assets/js/angular.min.js"></script>
    <script src="assets/js/angular-sanitize.min.js"></script>
    <script>
        function Search() {
            var state = $('#StateList').val();
            location.assign("search.php?State=" + state);
        }
    </script>
    <script>
        var app = angular.module('myApp', []);
        app.controller('customersCtrl', function ($scope, $http) {
            $scope.Record = { UID: 0 };
            $scope.Review = { Rating: 0, Preparedness: 0, Explaination: 0, TeachingAids: 0, Availability: 0, Discussion: 0, Examples: 0, Anonymous: false };
            $scope.SetRating = function (val) { $scope.Review.Rating = val; }
            $scope.SetPreparedness = function (val) { $scope.Review.Preparedness = val; }
            $scope.SetExplaination = function (val) { $scope.Review.Explaination = val; }
            $scope.SetTeachingAids = function (val) { $scope.Review.TeachingAids = val; }
            $scope.SetAvailability = function (val) { $scope.Review.Availability = val; }
            $scope.SetDiscussion = function (val) { $scope.Review.Discussion = val; }
            $scope.SetExamples = function (val) { $scope.Review.Examples = val; }

            var QueryString = QueryStringToJSON();
            //console.log(QueryString);

            $scope.CreateReview = function () {
                $scope.Review.FID = QueryString.FID;
                console.log($scope.Review);
                var data = JSON.stringify($scope.Review);
                $http.post("assets/api/AddFacultyReviewApi.php", data)
                .then(function (response) {

                    if (response.data.Status == 'Success') {
                        location.assign('viewfaculty.php?FID='+$scope.Review.FID);
                    }
                    else {alertify.error(response.data.Message);}
                });





            }

            $scope.ShowPanel = "Details";
            $scope.SetShowPanel = function (Panel) {$scope.ShowPanel = Panel;}
            $scope.Load = function () {
                $http.get("assets/api/GetUsers.php?UserType=Student").then(function (response) {
                    $scope.Records = response.data;
                    $scope.Records.forEach(Record => {

                            Record.ProfileImage = 'assets/img/Faculties/' + Record.FID + '.png?t=' + Date.now();
                        });
                console.log($scope.Records);
            });
            }
            //$scope.Load();

            $scope.SetToEdit = function (Record) {
                console.log(Record);
                $('#NewRecordModal').modal();
                $scope.Record = angular.copy(Record);
            }
            $scope.Delete = function (Record) {
                if (!confirm('Confirm Delete?')) return;
                 $http.get("assets/api/DeleteUsers.php?UID="+Record.FID).then(function (response) {
                $scope.Records = response.data;
                console.log($scope.Records);
            });
            }

        });

    </script>
</head>

<body ng-app="myApp" ng-controller="customersCtrl">
    <?php include('menu.php'); ?>

    <div class="container" style="margin-top: 80px;">
        <h4 class="text-secondary"><?php echo $Record["FacultyName"]; ?></h4>
    </div>
    <hr />
    <div class="container" style="margin-top: 19px;">
        <div class="card mb-4">
            <div class="card-body shadow-sm">
                <div class="row">
                    <div class="col-auto">
                       
                        <img class="border rounded shadow m-4" src="<?php echo "assets/img/Faculties/".$Record["FID"].".png"; ?>" style="max-width: 500px;" />
                    </div>
                    <div class="col">
                        <h4><?php echo $Record["FacultyName"]; ?></h4>
                        <hr />
                        <h5 class="text-info d-xl-flex align-items-xl-center mb-2">
                            <img src="assets/img/Users Student Filled.png" style="width: 36px;margin-right: 20px;" /><?php echo $Record["Designation"]; ?>
                        </h5>
                        
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>
                                            <h6 class="text-success d-xl-flex align-items-xl-center mb-2">
                                                <img src="assets/img/Star.png" style="width: 36px;margin-right: 20px;" />Ratings <?php echo round( $AvgRating["Rating"],1); ?> / 5 [<?php echo $Reviews->num_rows; ?> Votes]
                                            </h6>
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>
                                            <span>
                                                Teacher's Preparedness for the class
                                                <br />
                                            </span>
                                            <?php PrintProgressBarAdvanced ($AvgRating['Preparedness'],0,5,'','info');?>

                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <span>
                                                Ability to explain the topic
                                                <br />
                                            </span>
                                            <?php PrintProgressBarAdvanced ($AvgRating['Explaination'],0,5,'','info');?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <span>Use of Teaching aids</span>
                                            <?php PrintProgressBarAdvanced ($AvgRating['TeachingAids'],0,5,'','info');?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <span>
                                                Availability after the Class
                                                <br />
                                            </span>
                                            <?php PrintProgressBarAdvanced ($AvgRating['Availability'],0,5,'','info');?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <span>
                                                Does the teacher discuss the application aspects of the topics
                                                <br />
                                            </span>
                                            <?php PrintProgressBarAdvanced ($AvgRating['Discussion'],0,5,'','info');?>

                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <span>Does the teacher give enough examples to make the topic interesting &amp; understandable</span>
                                            <?php PrintProgressBarAdvanced ($AvgRating['Examples'],0,5,'','info');?>

                                        </td>
                                    </tr>

                                </tbody>
                            </table>
                        </div>
                        
                       
                        <div role="group" class="btn-group">
                            <?php if(isset($_SESSION['UID']) ){ ?>
                            <?php if(($_SESSION['User']['UserType'] == 'Student') && $_SESSION['User']['CID'] == $Record['CID']&& $_SESSION['User']['Course'] == $Record['Course']){ ?>
                                <button class="btn btn-primary" ng-click="SetShowPanel('AddReview')"  type="button">Write Reviews</button>
                                <?php } ?>
                            <?php } else{ ?>
                                <a class="btn btn-danger" href="login.php">Login to Write Review</a>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php if($Reviews->num_rows>0){ ?>
        <div class="container" ng-show="ShowPanel=='Details'">

                <div class="card shadow-sm">
                    <div class="card-header">
                        <h5 class="mb-0">Reviews</h5>
                    </div>
                    <div class="table-responsive">
                        <table class="table">
                            <tbody>
                                <?php if($Reviews)while($row= $Reviews->fetch_assoc())
                                 {
                                ?>
                                <tr>
                                    <td class="text-center" style="width: 124px;">
                                        <?php  if ($row["ReviewType"]=="Anonymous"){ ?>
                                            <img class="rounded-circle border rounded border-white shadow" src="assets/img/avatar_2x.png" style="max-width: 99px;" />
                                        <?php } else {  ?>
                                            <img class="rounded-circle border rounded border-white shadow" src="assets/img/Users/<?php echo $row["UID"]; ?>.png" style="max-width: 99px;" />
                                        <?php  } ?>

                                    </td>
                                    <td>
                                       
                               
                                            <div class="row">
                                                <div class="col">
                                                    <?php  if ($row["ReviewType"]=="Anonymous"){ ?>
                                                    <h6>Anonymous - ( <?php echo $row["UserType"]; ?> )</h6>
                                                    <?php } else { ?>
                                                    <h6><?php echo $row["UserName"]; ?></h6>
                                                    <?php  } ?>

                                                   
                                                </div>
                                                <?php if(isset($_SESSION["UID"]) && $_SESSION["UID"] == $row["UID"]){ ?>

                                                <div class="col-auto">
                                                    <a class="btn btn-danger" onclick="return confirm('Are you sure');"  href="viewfaculty.php?DeleteReview=<?php echo $row["FRID"]; ?>&FID=<?php echo $row["FID"]; ?>">
                                                        <i class="fa fa-remove"></i>
                                                    </a>
                                                </div>
                                                <?php  } ?>
                                                </div>
                                       

                                        <p class="text-secondary" style="font-size: 13px;margin-bottom: 8px;">
                                            <i class="fa fa-calendar" style="margin-right: 13px;"></i>
                                            <strong>
                                                <?php echo $row["ReviewDateTime"]; ?>
                                            </strong>
                                        </p>
                                        <p>
                                            <?php echo $row["Review"]; ?>
                                        </p>
                                    </td>
                                </tr>
                                <?php } else {  PrintAlert("No Record Found","Danger"); } ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
    <?php } ?>

    
    <div class="container" style="margin-top: 19px;" ng-show="ShowPanel=='AddReview'">
        <div class="card shadow-sm">
            <div class="card-header">
                <h5 class="mb-0">Add a review</h5>
            </div>
            <div class="card-body">
                <form>
                    <div class="form-row">
                        <div class="col">
                            <div class="form-group">
                                <p style="margin-bottom: 3px;font-size: 14px;">Teacher&#39;s Preparedness for the class</p>
                                <nav>
                                    <ul class="pagination">
                                        <li class="page-item"  ng-class="Review.Preparedness==1?'Active':''" ng-click="SetPreparedness(1)" >
                                            <a class="page-link">1</a>
                                        </li>
                                        <li class="page-item"  ng-class="Review.Preparedness==2?'Active':''" ng-click="SetPreparedness(2)" >
                                            <a class="page-link">2</a>
                                        </li>
                                        <li class="page-item"  ng-class="Review.Preparedness==3?'Active':''" ng-click="SetPreparedness(3)" >
                                            <a class="page-link">3</a>
                                        </li>
                                        <li class="page-item"  ng-class="Review.Preparedness==4?'Active':''" ng-click="SetPreparedness(4)" >
                                            <a class="page-link">4</a>
                                        </li>
                                        <li class="page-item"  ng-class="Review.Preparedness==5?'Active':''" ng-click="SetPreparedness(5)" >
                                            <a class="page-link">5</a>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <p style="margin-bottom: 3px;font-size: 14px;">Ability to explain the topic</p>
                                <nav>
                                    <ul class="pagination">
                                        <li class="page-item" ng-class="Review.Explaination==1?'Active':''" ng-click="SetExplaination(1)"  >
                                            <a class="page-link">1</a>
                                        </li>
                                        <li class="page-item" ng-class="Review.Explaination==2?'Active':''" ng-click="SetExplaination(2)"  >
                                            <a class="page-link">2</a>
                                        </li>
                                        <li class="page-item" ng-class="Review.Explaination==3?'Active':''" ng-click="SetExplaination(3)"  >
                                            <a class="page-link">3</a>
                                        </li>
                                        <li class="page-item" ng-class="Review.Explaination==4?'Active':''" ng-click="SetExplaination(4)"  >
                                            <a class="page-link">4</a>
                                        </li>
                                        <li class="page-item" ng-class="Review.Explaination==5?'Active':''" ng-click="SetExplaination(5)"  >
                                            <a class="page-link">5</a>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="col">
                            <div class="form-group">
                                <p style="margin-bottom: 3px;font-size: 14px;">
                                    Use of Teaching aids
                                    <br />
                                </p>
                                <nav>
                                    <ul class="pagination">
                                        <li class="page-item" ng-class="Review.TeachingAids==1?'Active':''" ng-click="SetTeachingAids(1)"  >
                                            <a class="page-link">1</a>
                                        </li>
                                        <li class="page-item" ng-class="Review.TeachingAids==2?'Active':''" ng-click="SetTeachingAids(2)"  >
                                            <a class="page-link">2</a>
                                        </li>
                                        <li class="page-item" ng-class="Review.TeachingAids==3?'Active':''" ng-click="SetTeachingAids(3)"  >
                                            <a class="page-link">3</a>
                                        </li>
                                        <li class="page-item" ng-class="Review.TeachingAids==4?'Active':''" ng-click="SetTeachingAids(4)"  >
                                            <a class="page-link">4</a>
                                        </li>
                                        <li class="page-item" ng-class="Review.TeachingAids==5?'Active':''" ng-click="SetTeachingAids(5)"  >
                                            <a class="page-link">5</a>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <p style="margin-bottom: 3px;font-size: 14px;">Availability after the Class</p>
                                <nav>
                                    <ul class="pagination">
                                        <li class="page-item" ng-class="Review.Availability==1?'Active':''" ng-click="SetAvailability(1)"  >
                                            <a class="page-link">1</a>
                                        </li>
                                        <li class="page-item" ng-class="Review.Availability==2?'Active':''" ng-click="SetAvailability(2)"  >
                                            <a class="page-link">2</a>
                                        </li>
                                        <li class="page-item" ng-class="Review.Availability==3?'Active':''" ng-click="SetAvailability(3)"  >
                                            <a class="page-link">3</a>
                                        </li>
                                        <li class="page-item" ng-class="Review.Availability==4?'Active':''" ng-click="SetAvailability(4)"  >
                                            <a class="page-link">4</a>
                                        </li>
                                        <li class="page-item" ng-class="Review.Availability==5?'Active':''" ng-click="SetAvailability(5)"  >
                                            <a class="page-link">5</a>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="col">
                            <div class="form-group">
                                <p style="margin-bottom: 3px;font-size: 14px;">Does the teacher discuss the application aspects of the topics</p>
                                <nav>
                                    <ul class="pagination">
                                        <li class="page-item" ng-class="Review.Discussion==1?'Active':''" ng-click="SetDiscussion(1)"  >
                                            <a class="page-link">1</a>
                                        </li>
                                        <li class="page-item" ng-class="Review.Discussion==2?'Active':''" ng-click="SetDiscussion(2)"  >
                                            <a class="page-link">2</a>
                                        </li>
                                        <li class="page-item" ng-class="Review.Discussion==3?'Active':''" ng-click="SetDiscussion(3)"  >
                                            <a class="page-link">3</a>
                                        </li>
                                        <li class="page-item" ng-class="Review.Discussion==4?'Active':''" ng-click="SetDiscussion(4)"  >
                                            <a class="page-link">4</a>
                                        </li>
                                        <li class="page-item" ng-class="Review.Discussion==5?'Active':''" ng-click="SetDiscussion(5)"  >
                                            <a class="page-link">5</a>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <p style="margin-bottom: 3px;font-size: 14px;">Does the teacher give enough examples to make the topic interesting &amp; understandable</p>
                                <nav>
                                    <ul class="pagination">
                                        <li class="page-item" ng-class="Review.Examples==1?'Active':''" ng-click="SetExamples(1)"  >
                                            <a class="page-link">1</a>
                                        </li>
                                        <li class="page-item" ng-class="Review.Examples==2?'Active':''" ng-click="SetExamples(2)"  >
                                            <a class="page-link">2</a>
                                        </li>
                                        <li class="page-item" ng-class="Review.Examples==3?'Active':''" ng-click="SetExamples(3)"  >
                                            <a class="page-link">3</a>
                                        </li>
                                        <li class="page-item" ng-class="Review.Examples==4?'Active':''" ng-click="SetExamples(4)"  >
                                            <a class="page-link">4</a>
                                        </li>
                                        <li class="page-item" ng-class="Review.Examples==5?'Active':''" ng-click="SetExamples(5)"  >
                                            <a class="page-link">5</a>
                                        </li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="col">
                            <div class="form-group">
                            <textarea class="form-control" rows="4" placeholder="Write a review" ng-model="Review.Review" name="Review"></textarea>
                            </div>
                        </div>
                        <div class="col d-xl-flex justify-content-xl-end align-items-xl-end">
                            <div class="form-group text-right">
                                <div class="form-row">
                                    <div class="col">
                                    
                                        <div class="custom-control custom-switch">
                                            <input type="checkbox" ng-model="Review.Anonymous" class="custom-control-input" id="formCheck-1" />
                                            <label class="custom-control-label" for="formCheck-1">Anonymous</label>
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div role="group" class="btn-group">
                                            <button class="btn btn-secondary" ng-click="SetShowPanel('Details')" type="button">Cancel</button>
                                            <button class="btn btn-success" ng-click="CreateReview()" type="button">Create</button>
                                        </div>
                                    </div>
                                </div>
                               
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/bs-init.js"></script>
</body>

</html>