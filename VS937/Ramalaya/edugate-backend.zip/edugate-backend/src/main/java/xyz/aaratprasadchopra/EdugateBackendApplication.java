package xyz.aaratprasadchopra;

import java.io.File;
import java.io.IOException;

import javax.annotation.PostConstruct;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.io.ClassPathResource;

@SpringBootApplication
public class EdugateBackendApplication {
	public static void main(String[] args) {
		SpringApplication.run(EdugateBackendApplication.class, args);
	}

	@PostConstruct
	public void pdf() throws Exception {
		var file = new ClassPathResource("consolidated list of all universities.pdf").getFile();
		var pdfDocument = PDDocument.load(file);
		var pdfTextStripper = new PDFTextStripper();
		String text = pdfTextStripper.getText(pdfDocument);
		// IRRESPECTIVE OF CASE
		System.out.println(text.contains("DEI"));
		pdfDocument.close();
	}



//	public boolean isUniversityReal(Registration registration) throws Exception {
//		var file = new File("/edugate-backend/src/main/resources/consolidated list of all universities.pdf");
//		var pdfDocument = PDDocument.load(file);
//		var pdfTextStripper = new PDFTextStripper();
//		String text = pdfTextStripper.getText(pdfDocument);
//		System.out.println(text);
//		pdfDocument.close();
//	}
}
