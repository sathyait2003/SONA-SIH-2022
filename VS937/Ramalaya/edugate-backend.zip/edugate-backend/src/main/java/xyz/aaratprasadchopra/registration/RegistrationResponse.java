package xyz.aaratprasadchopra.registration;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class RegistrationResponse {
	public String universityUniqueId;
	public String universityName;
	public String universityEmail;
	public String universityRegistrationId;
	public boolean isFake;
}
