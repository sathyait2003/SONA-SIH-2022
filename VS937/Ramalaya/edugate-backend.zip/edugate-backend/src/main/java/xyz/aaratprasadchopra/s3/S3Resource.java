package xyz.aaratprasadchopra.s3;

import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import lombok.AllArgsConstructor;

@AllArgsConstructor
@RestController
@RequestMapping("/api/s3")
public class S3Resource {
	private final S3Service service;
	
	@PostMapping("/upload")
	public boolean uploadFile(@RequestParam("file") MultipartFile file) {
		return this.service.uploadFile(null, file);
	}
}
