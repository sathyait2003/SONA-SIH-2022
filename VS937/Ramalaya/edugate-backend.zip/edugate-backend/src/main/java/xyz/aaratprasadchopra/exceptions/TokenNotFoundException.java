package xyz.aaratprasadchopra.exceptions;

public class TokenNotFoundException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public TokenNotFoundException() {
		super();
	}

	public TokenNotFoundException(String message) {
		super(message);
	}
}
