package xyz.aaratprasadchopra.exceptions;

public class UniversityNotFoundException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public UniversityNotFoundException() {
		super();
	}

	public UniversityNotFoundException(String message) {
		super(message);
	}
}
