package xyz.aaratprasadchopra.exceptions;

public class TokenExpiredException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public TokenExpiredException() {
		super();
	}

	public TokenExpiredException(String message) {
		super(message);
	}
}
