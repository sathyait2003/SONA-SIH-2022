package xyz.aaratprasadchopra.profile;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.AllArgsConstructor;
import xyz.aaratprasadchopra.university.UniversityService;

@RestController
@RequestMapping("/api/profile")
@AllArgsConstructor
public class ProfileResource {
	private final UniversityService universityService;

	@GetMapping("/university/{id}")
	public ProfileResponse getUniversityProfile(@PathVariable String id) {
		var university = this.universityService.getByUniqueId(id);
		return new ProfileResponse(university.getName(), university.getAddress().getStreet(), university.getAddress().getCity(), university.getAddress().getState(), university.getEmail(), university.getUniversityWebsite(), university.getRegistrationId());
	}
}
