package xyz.aaratprasadchopra.token;

import java.util.Optional;

public interface ConfirmationTokenService {
	boolean save(ConfirmationToken token);
	Optional<ConfirmationToken> getConfirmationToken(String token);
	boolean update(ConfirmationToken confirmationToken);
	boolean delete(String tokenUniqueId);
}
