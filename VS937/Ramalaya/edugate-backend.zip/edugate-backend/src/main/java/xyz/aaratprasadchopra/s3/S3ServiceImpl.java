package xyz.aaratprasadchopra.s3;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.PutObjectRequest;

import xyz.aaratprasadchopra.university.UniversityService;

@Service
public class S3ServiceImpl implements S3Service {
	private final AmazonS3 amazonS3;
	private UniversityService universityService;

	public S3ServiceImpl(AmazonS3 amazonS3, UniversityService universityService) {
		super();
		this.amazonS3 = amazonS3;
		this.universityService = universityService;
	}

	@Value("${application.bucket.name}")
	private String bucketName;

	@Override
	public boolean uploadFile(String uniqueId, MultipartFile file) {
		var university = this.universityService.getByUniqueId("ad526cca-a180-497c-a141-881687c9fd9b");
        var convertedFile = this.convertedMultipartFile(file);
        this.amazonS3.putObject(new PutObjectRequest(this.bucketName, university.getName() + "/" + file.getOriginalFilename(), convertedFile));
        convertedFile.delete(); // Delete the file from the local directly when saved in the S3 bucket.
		return true;
	}

    private File convertedMultipartFile(MultipartFile file) {
        var convertedFile = new File(Objects.requireNonNull(file.getOriginalFilename()));
        try (var outputStream = new FileOutputStream(convertedFile)) {
            outputStream.write(file.getBytes());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return convertedFile;
    }
}
