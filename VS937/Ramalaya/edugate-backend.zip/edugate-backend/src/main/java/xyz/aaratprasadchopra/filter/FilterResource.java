package xyz.aaratprasadchopra.filter;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.AllArgsConstructor;
import xyz.aaratprasadchopra.university.University;
import xyz.aaratprasadchopra.university.UniversityService;

@AllArgsConstructor
@RestController
@RequestMapping("/api/filter")
public class FilterResource {
	private final UniversityService universityService;

	@PostMapping("/search")
	public List<SearchFilterResponse> filterBySearch(@RequestBody SearchFilterRequestBody searchFilterRequestBody) {
		var universities = this.universityService.getUniversities();
		var upperCased = searchFilterRequestBody.getText().toUpperCase();
		List<University> filteredUniversities = universities.stream().filter(university -> university.getName().toUpperCase().matches(upperCased)).collect(Collectors.toList());
		var searchFilterResponseList = new ArrayList<SearchFilterResponse>();
		filteredUniversities.forEach(university -> searchFilterResponseList.add(new SearchFilterResponse(university.getUniqueId(), university.getName())));
		return searchFilterResponseList;
	}
}
