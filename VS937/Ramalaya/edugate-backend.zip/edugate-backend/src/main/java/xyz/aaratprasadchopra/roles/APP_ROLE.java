package xyz.aaratprasadchopra.roles;

public enum APP_ROLE {
	ADMIN,
	USER
}
