package xyz.aaratprasadchopra.address;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@Entity
public class Address {

	@Id
	private String uniqueId;
	private String street;
	private String city;
	private String state;
	private String country = "India";
	private String zipCode;

	public Address(String uniqueId, String street, String city, String state, String zipCode) {
		this.uniqueId = uniqueId;
		this.street = street;
		this.city = city;
		this.state = state;
		this.zipCode = zipCode;
	}
}
