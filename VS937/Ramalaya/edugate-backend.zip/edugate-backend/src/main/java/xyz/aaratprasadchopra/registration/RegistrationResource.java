package xyz.aaratprasadchopra.registration;

import java.io.File;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.springframework.core.io.ClassPathResource;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import lombok.AllArgsConstructor;
import xyz.aaratprasadchopra.address.Address;
import xyz.aaratprasadchopra.email.EmailSendingService;
import xyz.aaratprasadchopra.profile.ProfileResponse;
import xyz.aaratprasadchopra.roles.APP_ROLE;
import xyz.aaratprasadchopra.token.ConfirmationTokenService;
import xyz.aaratprasadchopra.university.University;
import xyz.aaratprasadchopra.university.UniversityResponse;
import xyz.aaratprasadchopra.university.UniversityService;

@AllArgsConstructor
@RestController
@RequestMapping("/api/registration")
public class RegistrationResource {
	private final UniversityService universityService;
	private final EmailSendingService emailSendingService;
	private final ConfirmationTokenService confirmationTokenService;

	@PostMapping("/register")
	public RegistrationResponse register(@RequestBody Registration registration) throws Exception {
		var universityId = UUID.randomUUID().toString();
		var isFake = this.isUniversityReal(registration);
		var token = this.universityService.save(new University(universityId, registration.getUniversityName(), registration.getEmail(), registration.getPassword(), isFake, registration.getRegistrationId(), registration.getWebsite(), APP_ROLE.USER, new Address(UUID.randomUUID().toString(), registration.getStreet(), registration.getCity(), registration.getState(), registration.getZipCode())));

		var confirmationLink = "http://localhost:8080/api/registration/confirm?token=" + token;
		this.emailSendingService.sendEmail(registration.getEmail(), this.emailInterfaceHTML(registration.getUniversityName(), confirmationLink));
		return new RegistrationResponse(universityId, registration.getUniversityName(), registration.getEmail(), registration.getRegistrationId(), isFake);
	}

	public boolean isUniversityReal(Registration registration) throws Exception {
		var file = new ClassPathResource("consolidated list of all universities.pdf").getFile();
		var pdfDocument = PDDocument.load(file);
		var pdfTextStripper = new PDFTextStripper();
		String text = pdfTextStripper.getText(pdfDocument);
		var upperText = text.toUpperCase();
		var name = registration.getUniversityName().toUpperCase();
		pdfDocument.close();
		return !upperText.matches(name);
	}

	@GetMapping("/confirm")
	public String confirmEmail(@RequestParam("token") String token) {
		return this.emailSendingService.confirmToken(token);
	}
	
	@GetMapping("/login")
	public ProfileResponse login(@RequestParam("email") String emailId) {
		var university = this.universityService.getByEmail(emailId);
		return new ProfileResponse(university.getName(), university.getAddress().getStreet(), university.getAddress().getCity(), university.getAddress().getState(), university.getEmail(), university.getUniversityWebsite(), university.getRegistrationId());
	}

	@GetMapping("/resend-new-token")
	public boolean resendToken(@RequestParam("id") String universityUniqueId) {
		var token = UUID.randomUUID().toString();
		var confirmationLink = "http://localhost:8080/api/registration/confirm?token=" + token;
		var university = this.universityService.getByUniqueId(universityUniqueId);
		var confirmationToken = university.getConfirmationToken();
		confirmationToken.setCreatedAt(LocalDateTime.now());
		confirmationToken.setExpiresAt(LocalDateTime.now().plusHours(1));
		confirmationToken.setToken(token);
		this.confirmationTokenService.update(confirmationToken);
		this.emailSendingService.sendEmail(university.getEmail(), this.emailInterfaceHTML(university.getName(), confirmationLink));
		System.out.println("SENT");
		return true;
	}

	@GetMapping("/universities")
	public List<UniversityResponse> getUniversities() {
		var universities = this.universityService.getUniversities();
		var uniRes = new ArrayList<UniversityResponse>();
		universities.forEach(university -> uniRes.add(new UniversityResponse(university.getUniqueId(), university.getName(), university.getAddress().getStreet(), university.getAddress().getCity(), university.getAddress().getState(), university.getAddress().getCountry(), university.getUniversityWebsite(), university.getAddress().getZipCode())));
		return uniRes;
	}

	@GetMapping("/{universityUniqueId}")
	public UniversityResponse getUniversity(@PathVariable String universityUniqueId) {
		var university = this.universityService.getByUniqueId(universityUniqueId);
		return new UniversityResponse(university.getUniqueId(), university.getName(), university.getAddress().getStreet(), university.getAddress().getCity(), university.getAddress().getState(), university.getAddress().getCountry(), university.getUniversityWebsite(), university.getAddress().getZipCode());
	}

    private String emailInterfaceHTML(String name, String link) {
        return "<!DOCTYPE html>\n" +
                "<html>\n" +
                "  <head>\n" +
                "    <title></title>\n" +
                "    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />\n" +
                "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" />\n" +
                "    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\" />\n" +
                "    <style type=\"text/css\">\n" +
                "      @media screen {\n" +
                "        @font-face {\n" +
                "          font-family: \"Lato\";\n" +
                "          font-style: normal;\n" +
                "          font-weight: 400;\n" +
                "          src: local(\"Lato Regular\"), local(\"Lato-Regular\"),\n" +
                "            url(https://fonts.gstatic.com/s/lato/v11/qIIYRU-oROkIk8vfvxw6QvesZW2xOQ-xsNqO47m55DA.woff)\n" +
                "              format(\"woff\");\n" +
                "        }\n" +
                "\n" +
                "        @font-face {\n" +
                "          font-family: \"Lato\";\n" +
                "          font-style: normal;\n" +
                "          font-weight: 700;\n" +
                "          src: local(\"Lato Bold\"), local(\"Lato-Bold\"),\n" +
                "            url(https://fonts.gstatic.com/s/lato/v11/qdgUG4U09HnJwhYI-uK18wLUuEpTyoUstqEm5AMlJo4.woff)\n" +
                "              format(\"woff\");\n" +
                "        }\n" +
                "\n" +
                "        @font-face {\n" +
                "          font-family: \"Lato\";\n" +
                "          font-style: italic;\n" +
                "          font-weight: 400;\n" +
                "          src: local(\"Lato Italic\"), local(\"Lato-Italic\"),\n" +
                "            url(https://fonts.gstatic.com/s/lato/v11/RYyZNoeFgb0l7W3Vu1aSWOvvDin1pK8aKteLpeZ5c0A.woff)\n" +
                "              format(\"woff\");\n" +
                "        }\n" +
                "\n" +
                "        @font-face {\n" +
                "          font-family: \"Lato\";\n" +
                "          font-style: italic;\n" +
                "          font-weight: 700;\n" +
                "          src: local(\"Lato Bold Italic\"), local(\"Lato-BoldItalic\"),\n" +
                "            url(https://fonts.gstatic.com/s/lato/v11/HkF_qI1x_noxlxhrhMQYELO3LdcAZYWl9Si6vvxL-qU.woff)\n" +
                "              format(\"woff\");\n" +
                "        }\n" +
                "      }\n" +
                "\n" +
                "      /* CLIENT-SPECIFIC STYLES */\n" +
                "      body,\n" +
                "      table,\n" +
                "      td,\n" +
                "      a {\n" +
                "        -webkit-text-size-adjust: 100%;\n" +
                "        -ms-text-size-adjust: 100%;\n" +
                "      }\n" +
                "\n" +
                "      table,\n" +
                "      td {\n" +
                "        mso-table-lspace: 0pt;\n" +
                "        mso-table-rspace: 0pt;\n" +
                "      }\n" +
                "\n" +
                "      img {\n" +
                "        -ms-interpolation-mode: bicubic;\n" +
                "      }\n" +
                "\n" +
                "      /* RESET STYLES */\n" +
                "      img {\n" +
                "        border: 0;\n" +
                "        height: auto;\n" +
                "        line-height: 100%;\n" +
                "        outline: none;\n" +
                "        text-decoration: none;\n" +
                "      }\n" +
                "\n" +
                "      table {\n" +
                "        border-collapse: collapse !important;\n" +
                "      }\n" +
                "\n" +
                "      body {\n" +
                "        height: 100% !important;\n" +
                "        margin: 0 !important;\n" +
                "        padding: 0 !important;\n" +
                "        width: 100% !important;\n" +
                "      }\n" +
                "\n" +
                "      /* iOS BLUE LINKS */\n" +
                "      a[x-apple-data-detectors] {\n" +
                "        color: inherit !important;\n" +
                "        text-decoration: none !important;\n" +
                "        font-size: inherit !important;\n" +
                "        font-family: inherit !important;\n" +
                "        font-weight: inherit !important;\n" +
                "        line-height: inherit !important;\n" +
                "      }\n" +
                "\n" +
                "      /* MOBILE STYLES */\n" +
                "      @media screen and (max-width: 600px) {\n" +
                "        h1 {\n" +
                "          font-size: 32px !important;\n" +
                "          line-height: 32px !important;\n" +
                "        }\n" +
                "      }\n" +
                "\n" +
                "      /* ANDROID CENTER FIX */\n" +
                "      div[style*=\"margin: 16px 0;\"] {\n" +
                "        margin: 0 !important;\n" +
                "      }\n" +
                "    </style>\n" +
                "  </head>\n" +
                "\n" +
                "  <body\n" +
                "    style=\"\n" +
                "      background-color: #f4f4f4;\n" +
                "      margin: 0 !important;\n" +
                "      padding: 0 !important;\n" +
                "    \"\n" +
                "  >\n" +
                "    <!-- HIDDEN PREHEADER TEXT -->\n" +
                "    <div\n" +
                "      style=\"\n" +
                "        display: none;\n" +
                "        font-size: 1px;\n" +
                "        color: #fefefe;\n" +
                "        line-height: 1px;\n" +
                "        font-family: 'Lato', Helvetica, Arial, sans-serif;\n" +
                "        max-height: 0px;\n" +
                "        max-width: 0px;\n" +
                "        opacity: 0;\n" +
                "        overflow: hidden;\n" +
                "      \"\n" +
                "    >\n" +
                "      We're thrilled to have you here! Get ready to dive into your new account.\n" +
                "    </div>\n" +
                "    <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">\n" +
                "      <!-- LOGO -->\n" +
                "      <tr>\n" +
                "        <td bgcolor=\"black\" align=\"center\">\n" +
                "          <table\n" +
                "            border=\"0\"\n" +
                "            cellpadding=\"0\"\n" +
                "            cellspacing=\"0\"\n" +
                "            width=\"100%\"\n" +
                "            style=\"max-width: 600px\"\n" +
                "          >\n" +
                "            <tr>\n" +
                "              <td\n" +
                "                align=\"center\"\n" +
                "                valign=\"top\"\n" +
                "                style=\"padding: 40px 10px 40px 10px\"\n" +
                "              ></td>\n" +
                "            </tr>\n" +
                "          </table>\n" +
                "        </td>\n" +
                "      </tr>\n" +
                "      <tr>\n" +
                "        <td bgcolor=\"black\" align=\"center\" style=\"padding: 0px 10px 0px 10px\">\n" +
                "          <table\n" +
                "            border=\"0\"\n" +
                "            cellpadding=\"0\"\n" +
                "            cellspacing=\"0\"\n" +
                "            width=\"100%\"\n" +
                "            style=\"max-width: 600px\"\n" +
                "          >\n" +
                "            <tr>\n" +
                "              <td\n" +
                "                bgcolor=\"#ffffff\"\n" +
                "                align=\"center\"\n" +
                "                valign=\"top\"\n" +
                "                style=\"\n" +
                "                  padding: 40px 20px 20px 20px;\n" +
                "                  border-radius: 4px 4px 0px 0px;\n" +
                "                  color: #111111;\n" +
                "                  font-family: 'Lato', Helvetica, Arial, sans-serif;\n" +
                "                  font-size: 48px;\n" +
                "                  font-weight: 400;\n" +
                "                  letter-spacing: 4px;\n" +
                "                  line-height: 48px;\n" +
                "                \"\n" +
                "              >\n" +
                "                <h1 style=\"font-size: 48px; font-weight: 400; margin: 2\">\n" +
                "                  Welcome!\n" +
                "                </h1>\n" +
                "                <img\n" +
                "                  src=\" https://img.icons8.com/clouds/100/000000/handshake.png\"\n" +
                "                  width=\"125\"\n" +
                "                  height=\"120\"\n" +
                "                  style=\"display: block; border: 0px\"\n" +
                "                />\n" +
                "              </td>\n" +
                "            </tr>\n" +
                "          </table>\n" +
                "        </td>\n" +
                "      </tr>\n" +
                "      <tr>\n" +
                "        <td bgcolor=\"#f4f4f4\" align=\"center\" style=\"padding: 0px 10px 0px 10px\">\n" +
                "          <table\n" +
                "            border=\"0\"\n" +
                "            cellpadding=\"0\"\n" +
                "            cellspacing=\"0\"\n" +
                "            width=\"100%\"\n" +
                "            style=\"max-width: 600px\"\n" +
                "          >\n" +
                "            <tr>\n" +
                "              <td\n" +
                "                bgcolor=\"#ffffff\"\n" +
                "                align=\"left\"\n" +
                "                style=\"\n" +
                "                  padding: 20px 30px 40px 30px;\n" +
                "                  color: #666666;\n" +
                "                  font-family: 'Lato', Helvetica, Arial, sans-serif;\n" +
                "                  font-size: 18px;\n" +
                "                  font-weight: 400;\n" +
                "                  line-height: 25px;\n" +
                "                \"\n" +
                "              >\n" +
                "                <p style=\"margin: 0\">\n" +
                "                  We're excited to have you get started. First, you need to\n" +
                "                  confirm your account. Just press the button below.\n" +
                "                </p>\n" +
                "              </td>\n" +
                "            </tr>\n" +
                "            <tr>\n" +
                "              <td bgcolor=\"#ffffff\" align=\"left\">\n" +
                "                <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\n" +
                "                  <tr>\n" +
                "                    <td\n" +
                "                      bgcolor=\"#ffffff\"\n" +
                "                      align=\"center\"\n" +
                "                      style=\"padding: 20px 30px 60px 30px\"\n" +
                "                    >\n" +
                "                      <table border=\"0\" cellspacing=\"0\" cellpadding=\"0\">\n" +
                "                        <tr>\n" +
                "                          <td\n" +
                "                            align=\"center\"\n" +
                "                            style=\"border-radius: 3px\"\n" +
                "                            bgcolor=\"#FFA73B\"\n" +
                "                          >\n" +
                "                            <a\n" +
                "                              href=\"" + link + "\"\n" +
                "                              target=\"_blank\"\n" +
                "                              style=\"\n" +
                "                                font-size: 20px;\n" +
                "                                font-family: Helvetica, Arial, sans-serif;\n" +
                "                                color: #ffffff;\n" +
                "                                text-decoration: none;\n" +
                "                                color: #ffffff;\n" +
                "                                text-decoration: none;\n" +
                "                                padding: 15px 25px;\n" +
                "                                border-radius: 2px;\n" +
                "                                border: 1px solid #ffa73b;\n" +
                "                                display: inline-block;\n" +
                "                              \"\n" +
                "                              >Confirm Account</a\n" +
                "                            >\n" +
                "                          </td>\n" +
                "                        </tr>\n" +
                "                      </table>\n" +
                "                    </td>\n" +
                "                  </tr>\n" +
                "                </table>\n" +
                "              </td>\n" +
                "            </tr>\n" +
                "            <!-- COPY -->\n" +
                "\n" +
                "            <tr>\n" +
                "              <td\n" +
                "                bgcolor=\"#ffffff\"\n" +
                "                align=\"left\"\n" +
                "                style=\"\n" +
                "                  padding: 0px 30px 40px 30px;\n" +
                "                  border-radius: 0px 0px 4px 4px;\n" +
                "                  color: #666666;\n" +
                "                  font-family: 'Lato', Helvetica, Arial, sans-serif;\n" +
                "                  font-size: 18px;\n" +
                "                  font-weight: 400;\n" +
                "                  line-height: 25px;\n" +
                "                \"\n" +
                "              >\n" +
                "                <p style=\"margin: 0\">Cheers,<br />Edugate Team</p>\n" +
                "              </td>\n" +
                "            </tr>\n" +
                "          </table>\n" +
                "        </td>\n" +
                "      </tr>\n" +
                "      <tr>\n" +
                "        <td\n" +
                "          bgcolor=\"#f4f4f4\"\n" +
                "          align=\"center\"\n" +
                "          style=\"padding: 30px 10px 0px 10px\"\n" +
                "        >\n" +
                "          <table\n" +
                "            border=\"0\"\n" +
                "            cellpadding=\"0\"\n" +
                "            cellspacing=\"0\"\n" +
                "            width=\"100%\"\n" +
                "            style=\"max-width: 600px\"\n" +
                "          >\n" +
                "            <tr>\n" +
                "              <td\n" +
                "                bgcolor=\"#FFECD1\"\n" +
                "                align=\"center\"\n" +
                "                style=\"\n" +
                "                  padding: 30px 30px 30px 30px;\n" +
                "                  border-radius: 4px 4px 4px 4px;\n" +
                "                  color: #666666;\n" +
                "                  font-family: 'Lato', Helvetica, Arial, sans-serif;\n" +
                "                  font-size: 18px;\n" +
                "                  font-weight: 400;\n" +
                "                  line-height: 25px;\n" +
                "                \"\n" +
                "              >\n" +
                "                <h2\n" +
                "                  style=\"\n" +
                "                    font-size: 20px;\n" +
                "                    font-weight: 400;\n" +
                "                    color: #111111;\n" +
                "                    margin: 0;\n" +
                "                  \"\n" +
                "                >\n" +
                "                  Need more help?\n" +
                "                </h2>\n" +
                "                <p style=\"margin: 0\">\n" +
                "                  <a href=\"#\" target=\"_blank\" style=\"color: #ffa73b\"\n" +
                "                    >We&rsquo;re here to help you out</a\n" +
                "                  >\n" +
                "                </p>\n" +
                "              </td>\n" +
                "            </tr>\n" +
                "          </table>\n" +
                "        </td>\n" +
                "      </tr>\n" +
                "      <tr>\n" +
                "        <td bgcolor=\"#f4f4f4\" align=\"center\" style=\"padding: 0px 10px 0px 10px\">\n" +
                "          <table\n" +
                "            border=\"0\"\n" +
                "            cellpadding=\"0\"\n" +
                "            cellspacing=\"0\"\n" +
                "            width=\"100%\"\n" +
                "            style=\"max-width: 600px\"\n" +
                "          >\n" +
                "            <tr>\n" +
                "              <td\n" +
                "                bgcolor=\"#f4f4f4\"\n" +
                "                align=\"left\"\n" +
                "                style=\"\n" +
                "                  padding: 0px 30px 30px 30px;\n" +
                "                  color: #666666;\n" +
                "                  font-family: 'Lato', Helvetica, Arial, sans-serif;\n" +
                "                  font-size: 14px;\n" +
                "                  font-weight: 400;\n" +
                "                  line-height: 18px;\n" +
                "                \"\n" +
                "              >\n" +
                "                <br />\n" +
                "                <p style=\"margin: 0\">\n" +
                "                  If these emails get annoying, please feel free to\n" +
                "                  <a\n" +
                "                    href=\"#\"\n" +
                "                    target=\"_blank\"\n" +
                "                    style=\"color: #111111; font-weight: 700\"\n" +
                "                    >unsubscribe</a\n" +
                "                  >.\n" +
                "                </p>\n" +
                "              </td>\n" +
                "            </tr>\n" +
                "          </table>\n" +
                "        </td>\n" +
                "      </tr>\n" +
                "    </table>\n" +
                "  </body>\n" +
                "</html>\n";
    }
}
