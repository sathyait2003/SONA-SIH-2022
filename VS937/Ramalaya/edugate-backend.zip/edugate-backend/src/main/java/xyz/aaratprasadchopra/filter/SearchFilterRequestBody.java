package xyz.aaratprasadchopra.filter;

import lombok.Data;

@Data
public class SearchFilterRequestBody {
	private String text;
}
