package xyz.aaratprasadchopra.email;

public interface EmailSendingService {
	String sendEmail(String to, String email);
	String confirmToken(String token);
}
