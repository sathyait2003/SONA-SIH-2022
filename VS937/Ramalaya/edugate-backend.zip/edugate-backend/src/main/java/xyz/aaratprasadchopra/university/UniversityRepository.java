package xyz.aaratprasadchopra.university;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface UniversityRepository extends JpaRepository<University, String> {
	Optional<University> findByEmail(String email);
	
	@Transactional
	@Modifying
	@Query("UPDATE University u" + " " + "SET u.isEmailVerified = TRUE WHERE u.email = ?1")
	void verifyUniversityEmail(String email);
}
