const BACKEND_BASE_URL = "http://localhost:8080";
export const REGISTRATION_API_URL = BACKEND_BASE_URL + "/api/registration";
export const PROFILE_API_URL = BACKEND_BASE_URL + "/api/profile";
export const UNIVERSITIES_API_URL =
  BACKEND_BASE_URL + "/api/registration/universities";
