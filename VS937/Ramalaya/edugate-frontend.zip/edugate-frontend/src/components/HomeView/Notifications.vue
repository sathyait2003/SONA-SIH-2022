<template>
  <div class="container">
    <div class="card">
      <div class="card-body">This is some text within a card body.</div>
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style></style>
