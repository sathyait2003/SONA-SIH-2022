<template>
  <Loader v-show="isLoading" />
  <div class="container">
    <div class="list">
      <h2 style="font-size: 50px">ENTER THE HEI's NAME</h2>
      <h4>With One Click, know whether it is fake or not.</h4>
    </div>
    <div class="search">
      <i class="fa fa-search"></i>
      <input
        type="text"
        class="form-control"
        placeholder="Enter the name of the HEI"
        v-model="inputValue"
        @input="watchInput"
      />
      <button @click="searchUniversities" class="btn btn-primary">
        Search
      </button>
    </div>

    <div v-if="universities.length" class="list-group">
      <router-link
        v-for="university in universities"
        :key="university.universityUniqueId"
        :to="{ name: 'about' }"
        class="list-group-item list-group-item-action"
        >{{ university.universityName }}</router-link
      >
      <!-- <a href="#" class="">A second link item</a>
      <a href="#" class="list-group-item list-group-item-action"
        >A third link item</a
      >
      <a href="#" class="list-group-item list-group-item-action"
        >A fourth link item</a
      > -->
    </div>
    <div v-show="isInputted">No HEI Found In The Database</div>
  </div>
</template>

<script>
import Loader from "../Loader.vue";
export default {
  name: "SearchCollege",
  data() {
    return {
      isLoading: false,
      universities: [],
      isInputted: false,
      inputValue: "",
    };
  },
  methods: {
    watchInput(e) {
      if (!e.target.value) this.isInputted = false;
    },

    async searchUniversities() {
      if (!this.inputValue) {
        this.isLoading = false;
        this.isInputted = false;
        this.universities = [];
      } else {
        this.isLoading = true;
        const res = await fetch("http://localhost:8080/api/filter/search", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
          },
          body: JSON.stringify({ text: this.inputValue }),
        });
        const data = await res.json();
        this.isLoading = false;
        this.universities = data;
        if (this.universities.length === 0) this.isInputted = true;
      }

      if (this.isInputted) {
        //         <router-link
        //   v-for="university in universities"
        //   :key="university.universityUniqueId"
        //   :to="{ name: 'about' }"
        //   class="list-group-item list-group-item-action"
        //   >{{ university.universityName }}</router-link
        // >
      }
    },

    search(e) {
      this.isLoading = true;
      let value = e.target.value;
      if (value === "") {
        this.universities = [];
        this.isLoading = false;
      } else {
        fetch("http://localhost:8080/api/filter/search", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
          },
          body: JSON.stringify({ text: value }),
        })
          .then((res) => res.json())
          .then((data) => {
            console.log(data);
            this.isLoading = false;
            this.universities = data;
          })
          .catch((e) => {
            this.isLoading = false;
            alert(e);
          });
      }

      if (value !== "" && !this.universities.length) {
        this.isInputted = true;
      } else {
        this.isInputted = false;
      }
    },
  },
  components: { Loader },
};
</script>

<style scoped>
.list {
  margin: 0 !important;
  outline: 0 !important;
  vertical-align: baseline !important;
  background: transparent !important;
  font-size: 40px !important;
  text-align: center !important;
  padding: 0px !important;
  margin: 10px !important;
  min-width: 980px !important;
  padding-top: 35px !important;
  padding-right: 40px !important;
  padding-bottom: 25px !important;
  padding-left: 20px !important;
}
.search {
  position: relative;
  box-shadow: 0 0 40px rgba(51, 51, 51, 0.1);
  margin-bottom: 10px;
}

.search input {
  height: 60px;
  text-indent: 20px;
  border: 2px solid #d6d4d4;
}

.search input:focus {
  box-shadow: none;
  border: 2px solid black;
}

.search .fa-search {
  position: absolute;
  top: 20px;
  left: 16px;
}

.search button {
  position: absolute;
  top: 5px;
  right: 5px;
  height: 50px;
  width: 110px;
  background: black;
}
</style>
