<template>
  <div class="footer-dark">
    <div class="container">
      <div class="row">
        <div class="col-sm-6 col-md-3 item">
          <h3>Important Links</h3>
          <ul>
            <li><a href="https://www.ugc.ac.in/" target="_blank">UGC</a></li>
            <li>
              <a href="https://www.aicte-india.org/" target="_blank">AICTE</a>
            </li>
            <li>
              <a href="https://www.education.gov.in/en" target="_blank"
                >Ministry of Education</a
              >
            </li>
          </ul>
        </div>
        <div class="col-sm-6 col-md-3 item">
          <h3>Content</h3>
          <ul>
            <li><a href="#">Home</a></li>
            <li><a href="#">About Us</a></li>
            <li><a href="#">Login</a></li>
          </ul>
        </div>
        <div class="col-md-6 item text">
          <h3>University Grants Commission</h3>
          <p class="ugc-des">
            The UGC has the unique distinction of being the only grant-giving
            agency in the country which has been vested with two
            responsibilities: that of providing funds and that of coordination,
            determination and maintenance of standards in institutions of higher
            education.
          </p>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Footer",
};
</script>

<style scoped>
.footer-dark {
  padding: 50px 0;
  color: #f0f9ff;
  background-color: #1a092b;
  margin-top: 1px;
}

.ugc-des {
  color: #9ea5ab;
}

.footer-dark h3 {
  margin-top: 0;
  margin-bottom: 12px;
  font-weight: bold;
  font-size: 16px;
}

.footer-dark ul {
  padding: 0;
  list-style: none;
  line-height: 1.6;
  font-size: 14px;
  margin-bottom: 0;
}

.footer-dark ul a {
  color: inherit;
  text-decoration: none;
  opacity: 0.6;
}

.footer-dark ul a:hover {
  opacity: 0.8;
}
</style>
