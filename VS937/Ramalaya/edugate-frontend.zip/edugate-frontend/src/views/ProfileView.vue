<template>
  <div class="container rounded bg-white mt-5 mb-5">
    <div class="row">
      <div class="col-md-3 border-right">
        <div class="d-flex flex-column align-items-center text-center p-3 py-5">
          <img
            class="rounded-circle mt-5"
            id="imgField"
            width="150px"
            src="https://st3.depositphotos.com/15648834/17930/v/600/depositphotos_179308454-stock-illustration-unknown-person-silhouette-glasses-profile.jpg"
          /><span class="font-weight-bold">Logo Image</span>
        </div>
        <label for="">Choose a Profile Picture</label>
        <br />
        <input id="file" type="file" />
      </div>
      <div class="col-md-5 border-right">
        <div class="p-3 py-5">
          <div class="d-flex justify-content-between align-items-center mb-3">
            <h4 class="text-right">Profile Settings</h4>
          </div>
          <div class="row mt-2">
            <div class="col-md-12">
              <label class="labels">HEI Name</label
              ><input
                type="text"
                placeholder="Name"
                class="form-control"
                :value="name"
              />
            </div>
          </div>
          <div class="row mt-3">
            <div class="col-md-12">
              <label class="labels">Address</label
              ><input type="text" class="form-control" placeholder="Address" />
            </div>
            <div class="col-md-12">
              <label class="labels">State</label
              ><input type="text" class="form-control" placeholder="State" />
            </div>
            <div class="col-md-12">
              <label class="labels">City</label
              ><input type="text" class="form-control" placeholder="City" />
            </div>

            <div class="col-md-12">
              <label class="labels">HEI Website</label
              ><input
                type="text"
                class="form-control"
                placeholder="e.g dei.ac.in"
              />
            </div>
            <div class="col-md-12">
              <label class="labels">Email ID</label
              ><input type="text" class="form-control" placeholder="Email" />
            </div>
          </div>

          <div class="mt-5 text-center">
            <button class="btn btn-primary profile-button" type="button">
              Save Profile
            </button>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="p-3 py-5">
          <div
            class="d-flex justify-content-between align-items-center experience"
          >
            <router-link :to="{ name: 'courseAdd' }" class="btn btn-primary"
              >Add Courses</router-link
            >
          </div>
          <br />
          <div class="col-md-12">
            <label class="labels">Additional Details</label
            ><input
              type="text"
              class="form-control"
              placeholder="additional details"
              value=""
            />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { PROFILE_API_URL } from "@/Global";
export default {
  name: "ProfileView",
  data() {
    return {
      name: String,
    };
    // return ["name", "street", "city", "state", "website", "email"];
  },
  created() {
    fetch(PROFILE_API_URL + "/university/" + this.$route.params.id)
      .then((res) => res.json())
      .then((data) => {
        this.name = data.universityName;
      });
  },
};
</script>

<style scoped>
.form-control:focus {
  box-shadow: none;
  border-color: #ba68c8;
}

.profile-button {
  background: rgb(99, 39, 120);
  box-shadow: none;
  border: none;
}

.profile-button:hover {
  background: #682773;
}

.profile-button:focus {
  background: #682773;
  box-shadow: none;
}

.profile-button:active {
  background: #682773;
  box-shadow: none;
}

.back:hover {
  color: #682773;
  cursor: pointer;
}

.labels {
  font-size: 11px;
}

.add-experience:hover {
  background: #ba68c8;
  color: #fff;
  cursor: pointer;
  border: solid 1px #ba68c8;
}
</style>
