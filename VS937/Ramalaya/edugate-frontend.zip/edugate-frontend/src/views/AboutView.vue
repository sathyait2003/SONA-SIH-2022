<template>
  <div class="main-div">
    <h1>Edugate</h1>
    <p class="desc">
      We are a platform which integrates all types of notified Universities
      (Central/State/Private/Deemed to be University/Open). Here HEIs/
      Universities can register themselves and provide information useful for
      students. Students can come and find their HEIs / Universities and get all
      the information before making any career decision. Here they can query
      universities offering conventional /distance/Online Education. We are a
      place where we update the list of fake universities on time to time basis.
    </p>

    <p>
      <span class="contact-heading">Contact:</span><br />Email:
      edugate@gmail.com<br />Mobile: 9634214072
    </p>
  </div>
</template>

<script>
export default {
  name: "AboutView",
};
</script>

<style scoped>
h1 {
  font-weight: bolder;
  margin-bottom: 10px;
  margin-top: 30px;
}

h2 {
  align-self: start;
}

.contact-heading {
  font-size: 20px;
  font-weight: bold;
}

.main-div {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  text-align: center;
  /* height: calc(100vh - 70px - 220px); */
  width: 100%;
  margin-bottom: 20px;
}

p {
  margin-top: 10px;
  width: 40%;
  text-align: justify;
}

h1 {
  margin: px;
  /* text-align: center; */
}

.img-fluid {
  display: block;
  margin-left: auto;
  margin-right: auto;
  width: 50%;
  margin-bottom: 20px;
}
</style>
