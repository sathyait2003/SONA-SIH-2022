<template>
  <div class="main-div">
    <nav>
      <Navbar />
    </nav>

    <section>
      <router-view />
    </section>

    <footer>
      <Footer />
    </footer>
  </div>
  <!-- <router-link to="/">Home</router-link> | -->
  <!-- <router-link to="/about">About</router-link> -->
</template>

<script>
import Navbar from "@/components/Navbar.vue";
import Footer from "@/components/Footer.vue";

export default {
  name: "App",
  components: { Navbar, Footer },
};
</script>

<style scoped></style>
