// import React, { useRef } from "react";
// import classes from "../Style/Captcha.module.css";
// import reCAPTCHA from "react-google-recaptcha";
// function Captcha() {
//   const TEST_SITE_KEY = "6LeQZKghAAAAAGUX_vX2CCVwltV5eoB7PJwefavB";
//   const captchaRef = useRef(null);
//   return (
//     <div className={classes.Captcha}>
//       <reCAPTCHA sitekey={TEST_SITE_KEY} ref={captchaRef} />
//     </div>
//   );
// }

// export default Captcha;
