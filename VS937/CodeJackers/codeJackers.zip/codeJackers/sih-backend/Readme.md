tasks remaining

- query - email verification (otp)

tasks done

- college + course integration
- delete for college(id) and course(id)
- register wale me slot , uname
- Registration
- Dashboard api
  - College details update
    short des
    long desc
    college logo
    prospectus
    full college add
    g map
    contact number
    college web
  - courses - create , update , getcourselist
    CourseName
    CourseDesc
    CourseIntakeCap
    AdmissionDOC
- create
- zoom ka link jana chiye hai register krne wala ko + govn official
- (if verify) => College gets verification success notification and can login in dashboard
- (if reject) => College gets verification reject notification
- getCollegesList
- Forget password
- login api
- getCollege(id)
- getCollege?q=city
- search college by name (http://localhost:3000/college/list?collegename=xyz)
